import com.mizandar.varantmatik.core.*;
import java.util.*;

public class CoreSelfTest {
    public static void main(String[] args) {
        // Daily change must compare against the previous completed session, not chart range previous close.
        assertNear(DailyChangeMath.percent(1786.0,1984.0),-9.9798387097,1e-6,"daily change DSTKF");
        assertNear(DailyChangeMath.percent(431.25,419.75),2.739725,1e-5,"daily change BIMAS example");

        testRsi();
        testMacdAtr();
        testDivergence();
        testAnalysisStateMachine();
        testNoChaseWithout4hConfirmation();
        testSupportResistanceBoundary();
        testBacktestWalkForward();
        testWarrant();
        System.out.println("ALL_CORE_TESTS_OK");
    }

    static void testRsi(){
        double[] x={44.34,44.09,44.15,43.61,44.33,44.83,45.10,45.42,45.84,46.08,45.89,46.03,45.61,46.28,46.28,46.00,46.03,46.41,46.22,45.64,46.21};
        double[] r=Indicators.rsi(x,14);
        double got=r[14];
        assertNear(got,70.464135,0.0005,"RSI Wilder");
    }

    static void testMacdAtr(){
        List<Candle> c=new ArrayList<>();
        for(int i=0;i<90;i++){
            double base=100+i*0.35+Math.sin(i/4.0)*2.0;
            c.add(new Candle(i*86400000L,base-0.5,base+1.1,base-1.0,base,1000+i));
        }
        double[] close=Indicators.closes(c);
        Indicators.Macd m=Indicators.macd(close,12,26,9);
        double[] a=Indicators.atr(c,14);
        if(Double.isNaN(Indicators.lastFinite(m.hist))) throw new AssertionError("MACD NaN");
        if(!(Indicators.lastFinite(a)>0)) throw new AssertionError("ATR invalid");
    }

    static void testDivergence(){
        List<Candle> c=new ArrayList<>();
        // Synthetic falling-lows series. RSI is supplied deliberately to isolate divergence rules.
        for(int i=0;i<50;i++){
            double p=100+Math.sin(i/3.0)*1.5;
            if(i==20)p=92; if(i==35)p=89;
            c.add(new Candle(i*86400000L,p,p+1,p-1,p,1000));
        }
        double[] rsi=new double[50]; Arrays.fill(rsi,50);
        rsi[20]=28; rsi[35]=36;
        Divergence d=DivergenceDetector.detect(c,rsi,2.0);
        if(d.type!=Divergence.Type.BULLISH) throw new AssertionError("Bullish divergence not detected: "+d.type);

        c.clear();
        for(int i=0;i<50;i++){
            double p=100+Math.sin(i/3.0)*1.5;
            if(i==20)p=108; if(i==35)p=112;
            c.add(new Candle(i*86400000L,p,p+1,p-1,p,1000));
        }
        Arrays.fill(rsi,50); rsi[20]=72; rsi[35]=62;
        d=DivergenceDetector.detect(c,rsi,2.0);
        if(d.type!=Divergence.Type.BEARISH) throw new AssertionError("Bearish divergence not detected: "+d.type);
    }


    static void testAnalysisStateMachine(){
        List<Candle> dailyUp=new ArrayList<>(), h4Up=new ArrayList<>();
        for(int i=0;i<260;i++){
            double p=100+i*0.42+Math.sin(i/6.0)*1.8;
            dailyUp.add(new Candle(i*86400000L,p-0.4,p+1.0,p-0.9,p,1000+i));
        }
        for(int i=0;i<100;i++){
            double p=150+i*0.08+i*i*0.0018+Math.sin(i/5.0)*0.4;
            h4Up.add(new Candle(i*4L*3600000L,p-0.2,p+0.5,p-0.5,p,800+i));
        }
        MarketAnalysis up=AnalysisEngine.analyze("TESTUP",dailyUp,h4Up,dailyUp.get(dailyUp.size()-1).close,1.2);
        if(!(up.state==MarketAnalysis.State.CONFIRM_UP||up.state==MarketAnalysis.State.STRONG_UP||up.state==MarketAnalysis.State.WATCH_UP))
            throw new AssertionError("Uptrend state unexpected: "+up.state+" reasons="+up.reasons);

        List<Candle> dailyDown=new ArrayList<>(), h4Down=new ArrayList<>();
        for(int i=0;i<260;i++){
            double p=220-i*0.42+Math.sin(i/6.0)*1.8;
            dailyDown.add(new Candle(i*86400000L,p+0.4,p+0.9,p-1.0,p,1000+i));
        }
        for(int i=0;i<100;i++){
            double p=170-i*0.08-i*i*0.0018+Math.sin(i/5.0)*0.4;
            h4Down.add(new Candle(i*4L*3600000L,p+0.2,p+0.5,p-0.5,p,800+i));
        }
        MarketAnalysis down=AnalysisEngine.analyze("TESTDOWN",dailyDown,h4Down,dailyDown.get(dailyDown.size()-1).close,-1.1);
        if(!(down.state==MarketAnalysis.State.CONFIRM_DOWN||down.state==MarketAnalysis.State.STRONG_DOWN||down.state==MarketAnalysis.State.WATCH_DOWN))
            throw new AssertionError("Downtrend state unexpected: "+down.state+" rsi4="+down.rsi4h+" m4="+down.macd4h+" reasons="+down.reasons);
    }


    static void testNoChaseWithout4hConfirmation(){
        List<Candle> daily=new ArrayList<>(), h4=new ArrayList<>();
        for(int i=0;i<260;i++){
            double p=220-i*0.42+Math.sin(i/6.0)*1.8;
            daily.add(new Candle(i*86400000L,p+0.4,p+0.9,p-1.0,p,1000+i));
        }
        // Trend aşağı, fakat son 4 saatlik momentum düşüş ivmesini kaybediyor. Sistem düşüşü kovalamamalı.
        for(int i=0;i<100;i++){
            double p=170-i*0.20+Math.sin(i/5.0)*0.8;
            h4.add(new Candle(i*4L*3600000L,p+0.2,p+0.5,p-0.5,p,800+i));
        }
        MarketAnalysis a=AnalysisEngine.analyze("NOCHASE",daily,h4,daily.get(daily.size()-1).close,-0.8);
        if(a.state==MarketAnalysis.State.STRONG_DOWN||a.state==MarketAnalysis.State.CONFIRM_DOWN)
            throw new AssertionError("System chased downside without 4h confirmation: "+a.state+" m4="+a.macd4h);
    }



    static void testSupportResistanceBoundary(){
        // Regression: pivot detection needs two candles on the right. The old loop
        // allowed i=size-2 and then accessed i+2 => IndexOutOfBounds at length 320.
        List<Candle> daily=new ArrayList<>();
        for(int i=0;i<320;i++){
            double p=100+i*0.03;
            double low=p-1.0, high=p+1.0;
            if(i==318) low=1.0;       // forces the boundary candidate
            if(i==319) low=2.0;
            daily.add(new Candle(i*86400000L,p-0.2,high,low,p,1000+i));
        }
        MarketAnalysis a=AnalysisEngine.analyze("BOUNDARY",daily,Collections.emptyList(),daily.get(319).close,0.0);
        if(a==null) throw new AssertionError("Boundary analysis returned null");
    }

    static void testBacktestWalkForward(){
        List<Candle> daily=new ArrayList<>(), h4=new ArrayList<>();
        long dayMs=86400000L;
        for(int i=0;i<520;i++){
            double p=100+i*0.22+Math.sin(i/7.0)*0.35;
            daily.add(new Candle(i*dayMs,p-0.2,p+0.6,p-0.6,p,1000+i));
            double p1=p-0.15, p2=p;
            h4.add(new Candle(i*dayMs+9*3600000L,p1-0.1,p1+0.25,p1-0.25,p1,500));
            h4.add(new Candle(i*dayMs+13*3600000L,p1,p2+0.25,p1-0.20,p2,500));
        }
        BacktestReport r=BacktestEngine.run("TREND",daily,h4,java.time.ZoneId.of("UTC"));
        if(r.signalCount<1) throw new AssertionError("Backtest produced no confirmation events");
        if(r.samples[2]<1) throw new AssertionError("Backtest 5d sample missing");
        if(!(r.avgSignedReturn[2]>0)) throw new AssertionError("Backtest trend return should be positive: "+r.avgSignedReturn[2]);
    }

    static void testWarrant(){
        WarrantMath.Result r=WarrantMath.evaluate(WarrantMath.Type.CALL,100,95,1.90,2.10,0.10,0.55);
        assertNear(r.mid,2.0,1e-9,"warrant mid");
        assertNear(r.spreadPct,10.0,1e-9,"warrant spread");
        assertNear(r.intrinsic,0.5,1e-9,"warrant intrinsic");
        assertNear(r.gearing,5.0,1e-9,"warrant gearing");
        assertNear(r.effectiveLeverage,2.75,1e-9,"warrant effective leverage");
    }

    static void assertNear(double a,double b,double eps,String name){ if(Math.abs(a-b)>eps) throw new AssertionError(name+" got="+a+" expected="+b); }
}
