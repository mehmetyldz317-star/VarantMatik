#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
OUT="$ROOT/build_core"
rm -rf "$OUT" && mkdir -p "$OUT"
javac -d "$OUT" "$ROOT"/app/src/main/java/com/mizandar/varantmatik/core/*.java "$ROOT"/tools/CoreSelfTest.java
java -cp "$OUT" CoreSelfTest
