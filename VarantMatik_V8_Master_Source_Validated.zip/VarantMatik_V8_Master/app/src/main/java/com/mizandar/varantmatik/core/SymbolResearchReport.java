package com.mizandar.varantmatik.core;

import java.time.LocalDate;

public final class SymbolResearchReport {
    public final String symbol;
    public final long startTime,endTime;
    public final LocalDate holdoutStart;
    public final ResearchStats all,up,down,bull,bear,sideways,development,holdout,strong;

    public SymbolResearchReport(String symbol,long startTime,long endTime,LocalDate holdoutStart,
        ResearchStats all,ResearchStats up,ResearchStats down,ResearchStats bull,ResearchStats bear,ResearchStats sideways,
        ResearchStats development,ResearchStats holdout,ResearchStats strong){
        this.symbol=symbol;this.startTime=startTime;this.endTime=endTime;this.holdoutStart=holdoutStart;
        this.all=all;this.up=up;this.down=down;this.bull=bull;this.bear=bear;this.sideways=sideways;
        this.development=development;this.holdout=holdout;this.strong=strong;
    }
}
