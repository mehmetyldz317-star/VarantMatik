package com.mizandar.varantmatik;

import android.content.Context;
import android.graphics.*;
import android.view.View;
import com.mizandar.varantmatik.core.Candle;
import java.util.*;

public final class MiniChartView extends View {
    private final Paint line=new Paint(Paint.ANTI_ALIAS_FLAG), grid=new Paint(Paint.ANTI_ALIAS_FLAG);
    private List<Candle> candles=Collections.emptyList();
    public MiniChartView(Context c){super(c);line.setColor(Color.rgb(79,209,154));line.setStrokeWidth(3f);line.setStyle(Paint.Style.STROKE);grid.setColor(Color.rgb(38,54,74));grid.setStrokeWidth(1f);}
    public void setCandles(List<Candle> c){candles=c==null?Collections.emptyList():c;invalidate();}
    protected void onDraw(Canvas canvas){super.onDraw(canvas);int w=getWidth(),h=getHeight();for(int i=1;i<4;i++)canvas.drawLine(0,h*i/4f,w,h*i/4f,grid);if(candles.size()<2)return;int n=Math.min(44,candles.size()),start=candles.size()-n;double lo=Double.POSITIVE_INFINITY,hi=Double.NEGATIVE_INFINITY;for(int i=start;i<candles.size();i++){double v=candles.get(i).close;lo=Math.min(lo,v);hi=Math.max(hi,v);}if(!(hi>lo))return;Path p=new Path();for(int j=0;j<n;j++){double v=candles.get(start+j).close;float x=j*(w-1f)/(n-1f);float y=(float)((hi-v)/(hi-lo)*(h-4))+2;if(j==0)p.moveTo(x,y);else p.lineTo(x,y);}canvas.drawPath(p,line);}
}
