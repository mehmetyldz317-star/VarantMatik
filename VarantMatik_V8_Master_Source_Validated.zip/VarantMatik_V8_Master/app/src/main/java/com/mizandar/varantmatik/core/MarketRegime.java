package com.mizandar.varantmatik.core;
public enum MarketRegime { BULL, BEAR, SIDEWAYS }
