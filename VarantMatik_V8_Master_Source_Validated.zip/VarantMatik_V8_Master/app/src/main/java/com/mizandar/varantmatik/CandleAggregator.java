package com.mizandar.varantmatik;

import com.mizandar.varantmatik.core.Candle;
import java.time.*;
import java.util.*;

public final class CandleAggregator {
    private CandleAggregator() {}
    public static List<Candle> to4h(List<Candle> hourly, ZoneId zone){
        ArrayList<Candle> out=new ArrayList<>();
        ArrayList<Candle> day=new ArrayList<>(); LocalDate current=null;
        for(Candle c:hourly){
            LocalDate d=Instant.ofEpochMilli(c.time).atZone(zone).toLocalDate();
            if(current!=null && !d.equals(current)){ flush(day,out); day.clear(); }
            current=d; day.add(c);
        }
        flush(day,out);
        return out;
    }
    private static void flush(List<Candle> day,List<Candle> out){
        for(int i=0;i+3<day.size();i+=4){
            Candle a=day.get(i); double hi=a.high,lo=a.low,vol=0; Candle z=day.get(i+3);
            for(int j=i;j<i+4;j++){ Candle c=day.get(j);hi=Math.max(hi,c.high);lo=Math.min(lo,c.low);vol+=c.volume; }
            out.add(new Candle(a.time,a.open,hi,lo,z.close,vol));
        }
    }
}
