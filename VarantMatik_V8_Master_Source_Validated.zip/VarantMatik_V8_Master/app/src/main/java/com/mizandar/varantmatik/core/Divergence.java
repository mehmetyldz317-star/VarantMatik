package com.mizandar.varantmatik.core;

public final class Divergence {
    public enum Type { NONE, BULLISH, BEARISH }
    public final Type type;
    public final int firstIndex;
    public final int secondIndex;
    public final double price1, price2, rsi1, rsi2;
    public final double strength;

    public Divergence(Type type, int firstIndex, int secondIndex,
                      double price1, double price2, double rsi1, double rsi2, double strength) {
        this.type = type;
        this.firstIndex = firstIndex;
        this.secondIndex = secondIndex;
        this.price1 = price1;
        this.price2 = price2;
        this.rsi1 = rsi1;
        this.rsi2 = rsi2;
        this.strength = strength;
    }

    public static Divergence none() {
        return new Divergence(Type.NONE, -1, -1, Double.NaN, Double.NaN, Double.NaN, Double.NaN, 0.0);
    }
}
