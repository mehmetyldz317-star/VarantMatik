package com.mizandar.varantmatik;

import android.content.*;
import org.json.*;
import java.util.*;

public final class AppStateStore {
    private final SharedPreferences sp;
    public AppStateStore(Context c){sp=c.getSharedPreferences("varantmatik_v8",Context.MODE_PRIVATE);}

    public Set<String> watchlist(){return new LinkedHashSet<>(sp.getStringSet("watchlist",Collections.emptySet()));}
    public boolean watched(String s){return watchlist().contains(s);}
    public void toggleWatch(String s){Set<String>x=watchlist();if(!x.add(s))x.remove(s);sp.edit().putStringSet("watchlist",x).apply();}

    public boolean guardEnabled(){return sp.getBoolean("guard_enabled",true);}
    public int guardMinutes(){return sp.getInt("guard_minutes",30);}
    public void setGuard(boolean enabled,int minutes){sp.edit().putBoolean("guard_enabled",enabled).putInt("guard_minutes",minutes).apply();}

    public int rotation(){return sp.getInt("rotation",0);}
    public void rotation(int i){sp.edit().putInt("rotation",i).apply();}
    public String previousState(String s){return sp.getString("state_"+s,"");}
    public void previousState(String s,String v){sp.edit().putString("state_"+s,v).apply();}
    public String previousPositionHealth(String key){return sp.getString("pos_health_"+key,"");}
    public void previousPositionHealth(String key,String v){sp.edit().putString("pos_health_"+key,v).apply();}

    public List<Position> positions(){
        ArrayList<Position> out=new ArrayList<>(); String raw=sp.getString("positions","[]");
        try{JSONArray a=new JSONArray(raw);for(int i=0;i<a.length();i++){JSONObject o=a.getJSONObject(i);out.add(new Position(o.getString("symbol"),o.optString("direction","UP"),o.optString("warrantCode",""),o.optDouble("underlyingEntry",Double.NaN),o.optLong("openedAt",0),o.optLong("expiryAt",0),o.optString("note","")));}}catch(Exception ignored){}
        return out;
    }
    public void addPosition(Position p){List<Position>x=positions();x.add(p);savePositions(x);}
    public void removePosition(int index){List<Position>x=positions();if(index>=0&&index<x.size()){x.remove(index);savePositions(x);}}
    private void savePositions(List<Position>x){
        JSONArray a=new JSONArray();
        for(Position p:x){
            try{
                JSONObject o=new JSONObject();
                o.put("symbol",p.symbol);o.put("direction",p.direction);o.put("warrantCode",p.warrantCode);
                if(Double.isFinite(p.underlyingEntry))o.put("underlyingEntry",p.underlyingEntry);else o.put("underlyingEntry",JSONObject.NULL);
                o.put("openedAt",p.openedAt);o.put("expiryAt",p.expiryAt);o.put("note",p.note);a.put(o);
            }catch(Exception ignored){}
        }
        sp.edit().putString("positions",a.toString()).apply();
    }
}
