package com.mizandar.varantmatik;

import java.util.*;

public final class ScanResult {
    public final List<RadarItem> items;
    public final int requested;
    public final List<String> failures;
    public ScanResult(List<RadarItem> items,int requested,List<String> failures){
        this.items=Collections.unmodifiableList(new ArrayList<>(items));
        this.requested=requested;
        this.failures=Collections.unmodifiableList(new ArrayList<>(failures));
    }
}
