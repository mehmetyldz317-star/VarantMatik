package com.mizandar.varantmatik;

import java.util.*;

public final class MarketUniverse {
    private MarketUniverse() {}
    // BIST 30 listesi: 01.07.2026-30.09.2026 dönemi; Q3'te bileşen değişikliği yoktur.
    public static final String[] BIST30 = {
        "AEFES","AKBNK","ASELS","ASTOR","BIMAS","DSTKF","EKGYO","ENKAI","EREGL","FROTO",
        "GARAN","GUBRF","ISCTR","KCHOL","KRDMD","MGROS","PETKM","PGSUS","SAHOL","SASA",
        "SISE","TAVHL","TCELL","THYAO","TOASO","TRALT","TTKOM","TUPRS","VAKBN","YKBNK"
    };
    public static List<String> all(){
        ArrayList<String> x=new ArrayList<>(); x.add("XU030"); x.add("DAX"); Collections.addAll(x,BIST30); return x;
    }
    public static String yahoo(String s){
        if("XU030".equals(s)) return "XU030.IS";
        if("DAX".equals(s)) return "^GDAXI";
        return s+".IS";
    }
    public static String display(String s){ return s; }
    public static java.time.ZoneId zone(String s){ return java.time.ZoneId.of("DAX".equals(s)?"Europe/Berlin":"Europe/Istanbul"); }
}
