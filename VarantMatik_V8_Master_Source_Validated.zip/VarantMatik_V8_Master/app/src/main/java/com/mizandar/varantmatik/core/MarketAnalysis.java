package com.mizandar.varantmatik.core;

import java.util.*;

public final class MarketAnalysis {
    public enum State {
        WAIT, WATCH_UP, WATCH_DOWN, CONFIRM_UP, CONFIRM_DOWN, STRONG_UP, STRONG_DOWN
    }

    public final String symbol;
    public final double price, changePct;
    public final double rsiDaily, rsi4h, macdDaily, macd4h;
    public final double ema20, ema50, ema200, atr;
    public final double support, resistance, invalidation;
    public final Divergence divergenceDaily;
    public final State state;
    public final int alignedChecks;
    public final List<String> reasons;

    public MarketAnalysis(String symbol,double price,double changePct,double rsiDaily,double rsi4h,
                          double macdDaily,double macd4h,double ema20,double ema50,double ema200,double atr,
                          double support,double resistance,double invalidation,Divergence divergenceDaily,
                          State state,int alignedChecks,List<String> reasons){
        this.symbol=symbol;this.price=price;this.changePct=changePct;this.rsiDaily=rsiDaily;this.rsi4h=rsi4h;
        this.macdDaily=macdDaily;this.macd4h=macd4h;this.ema20=ema20;this.ema50=ema50;this.ema200=ema200;this.atr=atr;
        this.support=support;this.resistance=resistance;this.invalidation=invalidation;this.divergenceDaily=divergenceDaily;
        this.state=state;this.alignedChecks=alignedChecks;this.reasons=Collections.unmodifiableList(new ArrayList<>(reasons));
    }

    public String label(){
        return switch(state){
            case STRONG_UP -> "YUKARI KOŞULLAR GÜÇLÜ";
            case STRONG_DOWN -> "AŞAĞI KOŞULLAR GÜÇLÜ";
            case CONFIRM_UP -> "YUKARI TEYİT GELİŞİYOR";
            case CONFIRM_DOWN -> "AŞAĞI TEYİT GELİŞİYOR";
            case WATCH_UP -> "YUKARI İZLE";
            case WATCH_DOWN -> "AŞAĞI İZLE";
            default -> "BEKLE";
        };
    }
}
