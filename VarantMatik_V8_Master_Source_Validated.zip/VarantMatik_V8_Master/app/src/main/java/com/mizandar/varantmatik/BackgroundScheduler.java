package com.mizandar.varantmatik;

import android.app.job.*;
import android.content.*;

public final class BackgroundScheduler {
    private static final int JOB=80421;
    private BackgroundScheduler(){}
    public static void apply(Context c){
        AppStateStore st=new AppStateStore(c);JobScheduler js=(JobScheduler)c.getSystemService(Context.JOB_SCHEDULER_SERVICE);if(js==null)return;
        js.cancel(JOB);if(!st.guardEnabled())return;
        long ms=Math.max(15,st.guardMinutes())*60_000L;
        JobInfo info=new JobInfo.Builder(JOB,new ComponentName(c,ScanJobService.class)).setRequiredNetworkType(JobInfo.NETWORK_TYPE_ANY).setPeriodic(ms).setPersisted(true).build();
        js.schedule(info);
    }
}
