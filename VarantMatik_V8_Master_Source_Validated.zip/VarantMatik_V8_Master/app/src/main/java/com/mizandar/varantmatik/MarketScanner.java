package com.mizandar.varantmatik;

import android.content.Context;
import com.mizandar.varantmatik.core.*;
import java.util.*;

public final class MarketScanner {
    public interface Progress { void onProgress(String text); }
    private final YahooFinanceProvider provider;
    public MarketScanner(Context c){provider=new YahooFinanceProvider(c);}

    public ScanResult fullScan(Set<String> priority, boolean force, Progress progress) throws Exception {
        ArrayList<RadarItem> first=new ArrayList<>(); ArrayList<String> failures=new ArrayList<>(); int i=0; List<String> all=MarketUniverse.all();
        for(String s:all){
            if(progress!=null)progress.onProgress("Günlük tarama "+(++i)+"/"+all.size()+" • "+s);
            try{
                MarketData d=provider.daily(s,force);
                if(d.candles.size()<80){ failures.add(s+" (yetersiz geçmiş: "+d.candles.size()+" mum)"); continue; }
                MarketAnalysis a=AnalysisEngine.analyze(s,d.candles,Collections.emptyList(),d.livePrice,d.changePct);
                first.add(new RadarItem(a,d.candles));
            }catch(Exception e){ failures.add(s+" ("+shortError(e)+")"); }
        }
        first.sort((a,b)->Integer.compare(b.analysis.alignedChecks,a.analysis.alignedChecks));
        LinkedHashSet<String> detail=new LinkedHashSet<>(); detail.add("XU030");detail.add("DAX"); if(priority!=null)detail.addAll(priority);
        for(RadarItem r:first){if(detail.size()>=12)break;detail.add(r.analysis.symbol);}
        Map<String,RadarItem> upgraded=new HashMap<>(); i=0;
        for(String s:detail){
            if(progress!=null)progress.onProgress("4 saat teyit "+(++i)+"/"+detail.size()+" • "+s);
            try{
                MarketData d=provider.daily(s,false), h=provider.hourly(s,force); List<Candle> h4=CandleAggregator.to4h(h.candles,MarketUniverse.zone(s));
                MarketAnalysis a=AnalysisEngine.analyze(s,d.candles,h4,d.livePrice,d.changePct); upgraded.put(s,new RadarItem(a,d.candles));
            }catch(Exception ignored){}
        }
        ArrayList<RadarItem> out=new ArrayList<>(); for(RadarItem r:first) out.add(upgraded.getOrDefault(r.analysis.symbol,r));
        out.sort((a,b)->{
            int sa=rank(a.analysis.state),sb=rank(b.analysis.state); if(sa!=sb)return Integer.compare(sb,sa); return Integer.compare(b.analysis.alignedChecks,a.analysis.alignedChecks);
        });
        return new ScanResult(out,all.size(),failures);
    }

    private static String shortError(Exception e){
        String m=e==null?"veri hatası":e.getMessage();
        if(m==null||m.isBlank())m=e.getClass().getSimpleName();
        m=m.replace('\n',' ').replace('\r',' ');
        return m.length()>48?m.substring(0,48)+"…":m;
    }

    public RadarItem scanOne(String s,boolean force)throws Exception{
        MarketData d=provider.daily(s,force),h=provider.hourly(s,force); List<Candle> h4=CandleAggregator.to4h(h.candles,MarketUniverse.zone(s));
        return new RadarItem(AnalysisEngine.analyze(s,d.candles,h4,d.livePrice,d.changePct),d.candles);
    }

    public BacktestReport backtest(String s,boolean force,Progress progress)throws Exception{
        if(progress!=null)progress.onProgress(s+" • 5 yıllık günlük geçmiş yükleniyor…");
        MarketData d=provider.historyDaily(s,force);
        if(progress!=null)progress.onProgress(s+" • uzun 60 dk geçmiş yükleniyor…");
        MarketData h=provider.historyHourly(s,force);
        if(progress!=null)progress.onProgress(s+" • 4 saat mumları oluşturuluyor…");
        List<Candle> h4=CandleAggregator.to4h(h.candles,MarketUniverse.zone(s));
        if(progress!=null)progress.onProgress(s+" • geçmiş sinyaller walk-forward test ediliyor…");
        return BacktestEngine.run(s,d.candles,h4,MarketUniverse.zone(s));
    }

    public Bist30ResearchReport researchBist30(boolean force,Progress progress)throws Exception{
        if(progress!=null)progress.onProgress("BIST30 • XU030 rejim geçmişi yükleniyor…");
        MarketData index=provider.historyDaily("XU030",force);
        java.time.ZoneId zone=MarketUniverse.zone("XU030");
        RegimeTimeline regimes=RegimeTimeline.from(index.candles,zone);
        java.time.LocalDate holdoutStart=chooseHoldoutStart(index.candles,zone);
        ArrayList<SymbolResearchReport> reports=new ArrayList<>();
        ArrayList<String> failures=new ArrayList<>();
        List<String> symbols=Bist30Membership.researchSymbols();
        int i=0;
        for(String s:symbols){
            if(progress!=null)progress.onProgress("BIST30 araştırma "+(++i)+"/"+symbols.size()+" • "+s);
            try{
                MarketData d=provider.historyDaily(s,force);
                MarketData h=provider.historyHourly(s,force);
                List<Candle> h4=CandleAggregator.to4h(h.candles,MarketUniverse.zone(s));
                SymbolResearchReport r=ResearchBacktestEngine.run(s,d.candles,h4,MarketUniverse.zone(s),regimes,holdoutStart);
                reports.add(r);
            }catch(Exception e){failures.add(s+" ("+shortError(e)+")");}
            try{Thread.sleep(180L);}catch(InterruptedException ie){Thread.currentThread().interrupt();throw new RuntimeException("Araştırma durduruldu");}
        }
        if(reports.isEmpty())throw new IllegalStateException("Hiçbir BIST30 dayanağı araştırılamadı");
        return new Bist30ResearchReport(reports,failures,holdoutStart);
    }

    private static java.time.LocalDate chooseHoldoutStart(List<Candle> index,java.time.ZoneId zone){
        java.time.LocalDate min=java.time.LocalDate.of(2024,10,1);
        ArrayList<java.time.LocalDate> dates=new ArrayList<>();
        for(Candle c:index){java.time.LocalDate d=java.time.Instant.ofEpochMilli(c.time).atZone(zone).toLocalDate();if(!d.isBefore(min))dates.add(d);}
        if(dates.size()<30)return min;
        int pos=(int)Math.floor((dates.size()-1)*0.70);
        return dates.get(Math.max(0,Math.min(pos,dates.size()-1)));
    }
    private static int rank(MarketAnalysis.State s){return switch(s){case STRONG_UP,STRONG_DOWN->4;case CONFIRM_UP,CONFIRM_DOWN->3;case WATCH_UP,WATCH_DOWN->2;default->1;};}
}
