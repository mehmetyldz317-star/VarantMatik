package com.mizandar.varantmatik;

import android.content.Context;
import com.mizandar.varantmatik.core.*;
import java.util.*;

public final class MarketScanner {
    public interface Progress { void onProgress(String text); }
    private final YahooFinanceProvider provider;
    public MarketScanner(Context c){provider=new YahooFinanceProvider(c);}

    public List<RadarItem> fullScan(Set<String> priority, boolean force, Progress progress) throws Exception {
        ArrayList<RadarItem> first=new ArrayList<>(); int i=0; List<String> all=MarketUniverse.all();
        for(String s:all){
            if(progress!=null)progress.onProgress("Günlük tarama "+(++i)+"/"+all.size()+" • "+s);
            try{
                MarketData d=provider.daily(s,force);
                if(d.candles.size()<80) continue;
                MarketAnalysis a=AnalysisEngine.analyze(s,d.candles,Collections.emptyList(),d.livePrice,d.changePct);
                first.add(new RadarItem(a,d.candles));
            }catch(Exception ignored){}
        }
        first.sort((a,b)->Integer.compare(b.analysis.alignedChecks,a.analysis.alignedChecks));
        LinkedHashSet<String> detail=new LinkedHashSet<>(); detail.add("XU030");detail.add("DAX"); if(priority!=null)detail.addAll(priority);
        for(RadarItem r:first){if(detail.size()>=12)break;detail.add(r.analysis.symbol);}
        Map<String,RadarItem> upgraded=new HashMap<>(); i=0;
        for(String s:detail){
            if(progress!=null)progress.onProgress("4 saat teyit "+(++i)+"/"+detail.size()+" • "+s);
            try{
                MarketData d=provider.daily(s,false), h=provider.hourly(s,force); List<Candle> h4=CandleAggregator.to4h(h.candles,MarketUniverse.zone(s));
                MarketAnalysis a=AnalysisEngine.analyze(s,d.candles,h4,d.livePrice,d.changePct); upgraded.put(s,new RadarItem(a,d.candles));
            }catch(Exception ignored){}
        }
        ArrayList<RadarItem> out=new ArrayList<>(); for(RadarItem r:first) out.add(upgraded.getOrDefault(r.analysis.symbol,r));
        out.sort((a,b)->{
            int sa=rank(a.analysis.state),sb=rank(b.analysis.state); if(sa!=sb)return Integer.compare(sb,sa); return Integer.compare(b.analysis.alignedChecks,a.analysis.alignedChecks);
        });
        return out;
    }

    public RadarItem scanOne(String s,boolean force)throws Exception{
        MarketData d=provider.daily(s,force),h=provider.hourly(s,force); List<Candle> h4=CandleAggregator.to4h(h.candles,MarketUniverse.zone(s));
        return new RadarItem(AnalysisEngine.analyze(s,d.candles,h4,d.livePrice,d.changePct),d.candles);
    }
    private static int rank(MarketAnalysis.State s){return switch(s){case STRONG_UP,STRONG_DOWN->4;case CONFIRM_UP,CONFIRM_DOWN->3;case WATCH_UP,WATCH_DOWN->2;default->1;};}
}
