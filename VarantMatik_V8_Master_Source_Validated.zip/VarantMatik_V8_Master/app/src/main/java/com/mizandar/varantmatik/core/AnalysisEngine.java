package com.mizandar.varantmatik.core;

import java.util.*;

public final class AnalysisEngine {
    private AnalysisEngine() {}

    public static MarketAnalysis analyze(String symbol, List<Candle> daily, List<Candle> h4, double livePrice, double changePct) {
        if (daily==null || daily.size()<80) throw new IllegalArgumentException("Yeterli günlük mum yok");
        double[] dc=Indicators.closes(daily), rsiD=Indicators.rsi(dc,14), e20=Indicators.ema(dc,20), e50=Indicators.ema(dc,50), e200=Indicators.ema(dc,200);
        Indicators.Macd md=Indicators.macd(dc,12,26,9); double[] atrArr=Indicators.atr(daily,14);
        double lastClose=dc[dc.length-1], rD=Indicators.lastFinite(rsiD), mD=Indicators.lastFinite(md.hist), a=Indicators.lastFinite(atrArr);
        double em20=Indicators.lastFinite(e20), em50=Indicators.lastFinite(e50), em200=Indicators.lastFinite(e200);
        Divergence div=DivergenceDetector.detect(daily,rsiD,a);
        double[] sr=supportResistance(daily,60); double support=sr[0], resistance=sr[1];

        double r4=Double.NaN,m4=Double.NaN,close4=Double.NaN,ema4=Double.NaN; boolean m4Rising=false;
        if(h4!=null && h4.size()>=35){
            double[] c4=Indicators.closes(h4), rr=Indicators.rsi(c4,14), ee=Indicators.ema(c4,20); Indicators.Macd mm=Indicators.macd(c4,12,26,9);
            r4=Indicators.lastFinite(rr); m4=Indicators.lastFinite(mm.hist); close4=c4[c4.length-1]; ema4=Indicators.lastFinite(ee);
            m4Rising = rising(mm.hist,3);
        }

        boolean upTrend = finite(em20)&&finite(em50) && lastClose>em20 && em20>em50 && (!finite(em200)||em50>em200);
        boolean downTrend = finite(em20)&&finite(em50) && lastClose<em20 && em20<em50 && (!finite(em200)||em50<em200);
        boolean nearSupport = finite(support)&&finite(a) && Math.abs(lastClose-support)<=a*1.25;
        boolean nearResistance = finite(resistance)&&finite(a) && Math.abs(lastClose-resistance)<=a*1.25;
        boolean up4 = finite(r4)&&finite(m4)&&finite(close4)&&finite(ema4) && r4>=50 && m4>0 && close4>ema4;
        boolean down4 = finite(r4)&&finite(m4)&&finite(close4)&&finite(ema4) && r4<=50 && m4<0 && close4<ema4;
        boolean up4Developing = finite(r4)&&finite(m4)&&r4>=44 && m4Rising;
        boolean down4Developing = finite(r4)&&finite(m4)&&r4<=56 && !m4Rising && m4<0;
        boolean breakout = finite(resistance)&&finite(a)&&lastClose>resistance+a*0.10;
        boolean breakdown = finite(support)&&finite(a)&&lastClose<support-a*0.10;

        int up=0, down=0; List<String> reasons=new ArrayList<>();
        if(upTrend){up++;reasons.add("Günlük ana trend yukarı");}
        if(downTrend){down++;reasons.add("Günlük ana trend aşağı");}
        if(div.type==Divergence.Type.BULLISH){up++;reasons.add("Günlük pozitif uyumsuzluk");}
        if(div.type==Divergence.Type.BEARISH){down++;reasons.add("Günlük negatif uyumsuzluk");}
        if(nearSupport){up++;reasons.add("Destek bölgesine yakın");}
        if(nearResistance){down++;reasons.add("Direnç bölgesine yakın");}
        if(up4){up+=2;reasons.add("4 saat momentum yukarı teyitli");}
        else if(up4Developing){up++;reasons.add("4 saat momentum toparlanıyor");}
        if(down4){down+=2;reasons.add("4 saat momentum aşağı teyitli");}
        else if(down4Developing){down++;reasons.add("4 saat momentum zayıflıyor");}
        if(breakout){up++;reasons.add("Direnç üstü kapanış");}
        if(breakdown){down++;reasons.add("Destek altı kapanış");}

        MarketAnalysis.State state=MarketAnalysis.State.WAIT;
        if(up>=5 && up>=down+2) state=MarketAnalysis.State.STRONG_UP;
        else if(down>=5 && down>=up+2) state=MarketAnalysis.State.STRONG_DOWN;
        else if(up>=3 && up>=down+1) state=MarketAnalysis.State.CONFIRM_UP;
        else if(down>=3 && down>=up+1) state=MarketAnalysis.State.CONFIRM_DOWN;
        else if(up>=2 && up>down) state=MarketAnalysis.State.WATCH_UP;
        else if(down>=2 && down>up) state=MarketAnalysis.State.WATCH_DOWN;

        double invalidation=Double.NaN;
        if(state==MarketAnalysis.State.STRONG_UP||state==MarketAnalysis.State.CONFIRM_UP||state==MarketAnalysis.State.WATCH_UP)
            invalidation=finite(support)&&finite(a)?support-a*0.5:Double.NaN;
        else if(state==MarketAnalysis.State.STRONG_DOWN||state==MarketAnalysis.State.CONFIRM_DOWN||state==MarketAnalysis.State.WATCH_DOWN)
            invalidation=finite(resistance)&&finite(a)?resistance+a*0.5:Double.NaN;

        return new MarketAnalysis(symbol,livePrice,changePct,rD,r4,mD,m4,em20,em50,em200,a,support,resistance,invalidation,div,state,Math.max(up,down),reasons);
    }

    private static boolean finite(double x){return !Double.isNaN(x)&&!Double.isInfinite(x);}
    private static boolean rising(double[] a,int n){
        int last=-1; for(int i=a.length-1;i>=0;i--) if(finite(a[i])){last=i;break;} if(last<0)return false;
        int first=last-n; if(first<0||!finite(a[first])) return false; return a[last]>a[first];
    }
    private static double[] supportResistance(List<Candle> c,int lookback){
        int start=Math.max(2,c.size()-lookback), end=c.size()-2; double sup=Double.NaN,res=Double.NaN;
        for(int i=end;i>=start;i--){
            if(Double.isNaN(sup)&&c.get(i).low<c.get(i-1).low&&c.get(i).low<c.get(i-2).low&&c.get(i).low<c.get(i+1).low&&c.get(i).low<c.get(i+2).low) sup=c.get(i).low;
            if(Double.isNaN(res)&&c.get(i).high>c.get(i-1).high&&c.get(i).high>c.get(i-2).high&&c.get(i).high>c.get(i+1).high&&c.get(i).high>c.get(i+2).high) res=c.get(i).high;
            if(finite(sup)&&finite(res))break;
        }
        return new double[]{sup,res};
    }
}
