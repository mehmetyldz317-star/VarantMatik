package com.mizandar.varantmatik.core;

import java.time.*;
import java.util.*;

/**
 * Walk-forward doğrulama: yalnız o tarihe kadar bilinen mumları kullanır.
 * Aynı yöndeki CONFIRM/STRONG durumu devam ederken her günü yeni sinyal saymaz;
 * yalnız yeni bir teyit serisi başladığında olay kaydeder.
 */
public final class BacktestEngine {
    private BacktestEngine(){}
    private static final int[] H={1,3,5,10,20};

    public static BacktestReport run(String symbol,List<Candle> daily,List<Candle> h4,ZoneId zone){
        if(daily==null||daily.size()<260) throw new IllegalArgumentException("Backtest için en az 260 günlük mum gerekli");
        if(h4==null||h4.size()<80) throw new IllegalArgumentException("Backtest için yeterli 4 saat verisi yok");

        int[] samples=new int[H.length],wins=new int[H.length];
        double[] sums=new double[H.length];
        int signals=0,ups=0,downs=0,strong=0,prevDir=0;
        double fav20Sum=0,adv20Sum=0;int excursionN=0;
        long firstEval=0,lastEval=0;

        LocalDate first4=Instant.ofEpochMilli(h4.get(0).time).atZone(zone).toLocalDate();
        int hEnd=-1;
        for(int i=220;i<daily.size();i++){
            LocalDate day=Instant.ofEpochMilli(daily.get(i).time).atZone(zone).toLocalDate();
            while(hEnd+1<h4.size()){
                LocalDate hd=Instant.ofEpochMilli(h4.get(hEnd+1).time).atZone(zone).toLocalDate();
                if(hd.isAfter(day)) break;
                hEnd++;
            }
            if(day.isBefore(first4)||hEnd<40){prevDir=0;continue;}
            if(firstEval==0)firstEval=daily.get(i).time;
            lastEval=daily.get(i).time;

            int ds=Math.max(0,i-319);
            int hs=Math.max(0,hEnd-179);
            List<Candle> dSlice=daily.subList(ds,i+1);
            List<Candle> hSlice=h4.subList(hs,hEnd+1);
            double close=daily.get(i).close;
            double change=i>0&&daily.get(i-1).close!=0?(close/daily.get(i-1).close-1.0)*100.0:Double.NaN;
            MarketAnalysis a=AnalysisEngine.analyze(symbol,dSlice,hSlice,close,change);
            int dir=direction(a.state);
            if(dir!=0 && dir!=prevDir){
                signals++; if(dir>0)ups++;else downs++;
                if(a.state==MarketAnalysis.State.STRONG_UP||a.state==MarketAnalysis.State.STRONG_DOWN)strong++;
                // Sinyal günlük kapanışta oluşur. Aynı kapanıştan gerçekleşmiş varsaymamak için
                // ölçüm, sonraki işlem gününün açılışından başlar.
                if(i+1<daily.size() && daily.get(i+1).open>0){
                    double entry=daily.get(i+1).open;
                    for(int k=0;k<H.length;k++){
                        int j=i+H[k]; if(j>=daily.size())continue;
                        double ret=dir*(daily.get(j).close/entry-1.0)*100.0;
                        samples[k]++;sums[k]+=ret;if(ret>0)wins[k]++;
                    }
                    if(i+20<daily.size()){
                        double best=Double.NEGATIVE_INFINITY,worst=Double.POSITIVE_INFINITY;
                        for(int j=i+1;j<=i+20;j++){
                            Candle c=daily.get(j);
                            double favorable,adverse;
                            if(dir>0){favorable=(c.high/entry-1.0)*100.0;adverse=(c.low/entry-1.0)*100.0;}
                            else{favorable=(1.0-c.low/entry)*100.0;adverse=(1.0-c.high/entry)*100.0;}
                            best=Math.max(best,favorable);worst=Math.min(worst,adverse);
                        }
                        fav20Sum+=best;adv20Sum+=worst;excursionN++;
                    }
                }
            }
            prevDir=dir;
        }
        double[] avg=new double[H.length];
        for(int k=0;k<H.length;k++)avg[k]=samples[k]==0?Double.NaN:sums[k]/samples[k];
        if(firstEval==0){firstEval=daily.get(Math.max(0,daily.size()-1)).time;lastEval=firstEval;}
        return new BacktestReport(symbol,firstEval,lastEval,signals,ups,downs,strong,H,samples,wins,avg,
            excursionN==0?Double.NaN:fav20Sum/excursionN,excursionN==0?Double.NaN:adv20Sum/excursionN);
    }

    private static int direction(MarketAnalysis.State s){
        return switch(s){
            case CONFIRM_UP,STRONG_UP -> 1;
            case CONFIRM_DOWN,STRONG_DOWN -> -1;
            default -> 0;
        };
    }
}
