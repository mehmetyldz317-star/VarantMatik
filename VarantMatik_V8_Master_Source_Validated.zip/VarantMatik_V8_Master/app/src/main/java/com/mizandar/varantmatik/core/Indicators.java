package com.mizandar.varantmatik.core;

import java.util.*;

public final class Indicators {
    private Indicators() {}

    public static double[] closes(List<Candle> c) {
        double[] out = new double[c.size()];
        for (int i=0;i<c.size();i++) out[i] = c.get(i).close;
        return out;
    }

    public static double[] ema(double[] values, int period) {
        double[] out = new double[values.length];
        Arrays.fill(out, Double.NaN);
        if (period <= 0 || values.length < period) return out;
        double sum = 0;
        for (int i=0;i<period;i++) sum += values[i];
        double prev = sum / period;
        out[period-1] = prev;
        double k = 2.0 / (period + 1.0);
        for (int i=period;i<values.length;i++) {
            prev = values[i] * k + prev * (1.0-k);
            out[i] = prev;
        }
        return out;
    }

    /** Wilder RSI, period 14 by default. */
    public static double[] rsi(double[] values, int period) {
        double[] out = new double[values.length];
        Arrays.fill(out, Double.NaN);
        if (period <= 0 || values.length <= period) return out;
        double gain = 0, loss = 0;
        for (int i=1;i<=period;i++) {
            double d = values[i]-values[i-1];
            if (d >= 0) gain += d; else loss -= d;
        }
        double avgGain = gain / period;
        double avgLoss = loss / period;
        out[period] = rsiFromAverages(avgGain, avgLoss);
        for (int i=period+1;i<values.length;i++) {
            double d = values[i]-values[i-1];
            double g = Math.max(d,0), l = Math.max(-d,0);
            avgGain = (avgGain*(period-1)+g)/period;
            avgLoss = (avgLoss*(period-1)+l)/period;
            out[i] = rsiFromAverages(avgGain, avgLoss);
        }
        return out;
    }

    private static double rsiFromAverages(double gain, double loss) {
        if (loss == 0) return 100.0;
        if (gain == 0) return 0.0;
        double rs = gain/loss;
        return 100.0 - (100.0/(1.0+rs));
    }

    public static final class Macd {
        public final double[] line, signal, hist;
        Macd(double[] line, double[] signal, double[] hist) {
            this.line=line; this.signal=signal; this.hist=hist;
        }
    }

    public static Macd macd(double[] values, int fast, int slow, int signalPeriod) {
        double[] ef = ema(values, fast), es = ema(values, slow);
        double[] line = new double[values.length]; Arrays.fill(line, Double.NaN);
        for (int i=0;i<values.length;i++) if (!Double.isNaN(ef[i]) && !Double.isNaN(es[i])) line[i]=ef[i]-es[i];

        double[] compact = new double[values.length]; int[] map = new int[values.length]; int n=0;
        for (int i=0;i<line.length;i++) if (!Double.isNaN(line[i])) { compact[n]=line[i]; map[n]=i; n++; }
        compact = Arrays.copyOf(compact,n); map=Arrays.copyOf(map,n);
        double[] signal = new double[values.length], hist = new double[values.length];
        Arrays.fill(signal,Double.NaN); Arrays.fill(hist,Double.NaN);
        if (n>0) {
            double[] sCompact = ema(compact, signalPeriod);
            for (int j=0;j<n;j++) {
                int i=map[j];
                if (!Double.isNaN(sCompact[j])) {
                    signal[i]=sCompact[j];
                    hist[i]=line[i]-signal[i];
                }
            }
        }
        return new Macd(line,signal,hist);
    }

    public static double[] atr(List<Candle> c, int period) {
        double[] out = new double[c.size()]; Arrays.fill(out,Double.NaN);
        if (c.size() <= period) return out;
        double[] tr = new double[c.size()];
        tr[0]=c.get(0).high-c.get(0).low;
        for (int i=1;i<c.size();i++) {
            Candle x=c.get(i), p=c.get(i-1);
            tr[i]=Math.max(x.high-x.low, Math.max(Math.abs(x.high-p.close), Math.abs(x.low-p.close)));
        }
        double sum=0; for(int i=1;i<=period;i++) sum+=tr[i];
        double prev=sum/period; out[period]=prev;
        for(int i=period+1;i<c.size();i++) { prev=(prev*(period-1)+tr[i])/period; out[i]=prev; }
        return out;
    }

    public static double lastFinite(double[] a) {
        for (int i=a.length-1;i>=0;i--) if (!Double.isNaN(a[i]) && !Double.isInfinite(a[i])) return a[i];
        return Double.NaN;
    }

    public static double finiteAt(double[] a, int i) {
        return (i>=0 && i<a.length && !Double.isNaN(a[i])) ? a[i] : Double.NaN;
    }
}
