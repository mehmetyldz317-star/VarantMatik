package com.mizandar.varantmatik;
import com.mizandar.varantmatik.core.*;
import java.util.*;
public final class RadarItem {
    public final MarketAnalysis analysis; public final List<Candle> daily;
    public RadarItem(MarketAnalysis analysis,List<Candle> daily){this.analysis=analysis;this.daily=daily;}
}
