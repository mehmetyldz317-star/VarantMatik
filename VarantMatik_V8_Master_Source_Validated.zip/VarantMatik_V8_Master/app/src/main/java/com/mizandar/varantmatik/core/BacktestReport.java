package com.mizandar.varantmatik.core;

import java.util.Arrays;

public final class BacktestReport {
    public final String symbol;
    public final long startTime, endTime;
    public final int signalCount, upSignals, downSignals, strongSignals;
    public final int[] horizons, samples, wins;
    public final double[] avgSignedReturn;
    public final double avgFavorable20, avgAdverse20;

    public BacktestReport(String symbol,long startTime,long endTime,int signalCount,int upSignals,int downSignals,int strongSignals,
                          int[] horizons,int[] samples,int[] wins,double[] avgSignedReturn,double avgFavorable20,double avgAdverse20){
        this.symbol=symbol;this.startTime=startTime;this.endTime=endTime;this.signalCount=signalCount;
        this.upSignals=upSignals;this.downSignals=downSignals;this.strongSignals=strongSignals;
        this.horizons=Arrays.copyOf(horizons,horizons.length);this.samples=Arrays.copyOf(samples,samples.length);
        this.wins=Arrays.copyOf(wins,wins.length);this.avgSignedReturn=Arrays.copyOf(avgSignedReturn,avgSignedReturn.length);
        this.avgFavorable20=avgFavorable20;this.avgAdverse20=avgAdverse20;
    }

    public double successPct(int i){return samples[i]==0?Double.NaN:(wins[i]*100.0/samples[i]);}
}
