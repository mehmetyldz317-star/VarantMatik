package com.mizandar.varantmatik.core;

import java.time.*;
import java.util.*;

/** Causal XU030 regime classification: only information available up to each date is used. */
public final class RegimeTimeline {
    private final Map<LocalDate,MarketRegime> byDate;
    private final MarketRegime fallback;

    private RegimeTimeline(Map<LocalDate,MarketRegime> byDate, MarketRegime fallback){
        this.byDate=byDate; this.fallback=fallback;
    }

    public static RegimeTimeline from(List<Candle> indexDaily, ZoneId zone){
        if(indexDaily==null||indexDaily.size()<60) throw new IllegalArgumentException("Rejim için XU030 geçmişi yetersiz");
        double[] close=Indicators.closes(indexDaily);
        double[] e50=Indicators.ema(close,50), e200=Indicators.ema(close,200);
        HashMap<LocalDate,MarketRegime> map=new HashMap<>();
        MarketRegime last=MarketRegime.SIDEWAYS;
        for(int i=0;i<indexDaily.size();i++){
            double c=close[i], f=e50[i], s=e200[i];
            MarketRegime r=MarketRegime.SIDEWAYS;
            if(finite(f)&&finite(s)){
                double past=(i>=10&&finite(e50[i-10]))?e50[i-10]:f;
                if(c>f && f>s && f>past) r=MarketRegime.BULL;
                else if(c<f && f<s && f<past) r=MarketRegime.BEAR;
            }
            last=r;
            LocalDate d=Instant.ofEpochMilli(indexDaily.get(i).time).atZone(zone).toLocalDate();
            map.put(d,r);
        }
        return new RegimeTimeline(map,last);
    }

    public MarketRegime on(LocalDate d){
        MarketRegime r=byDate.get(d);
        if(r!=null)return r;
        // For holidays/mismatched timestamps use the latest prior trading-day regime.
        LocalDate x=d;
        for(int i=0;i<7;i++){x=x.minusDays(1);r=byDate.get(x);if(r!=null)return r;}
        return fallback;
    }
    private static boolean finite(double x){return !Double.isNaN(x)&&!Double.isInfinite(x);}
}
