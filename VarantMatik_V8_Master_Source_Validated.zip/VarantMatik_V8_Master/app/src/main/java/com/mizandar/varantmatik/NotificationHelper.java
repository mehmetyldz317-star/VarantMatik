package com.mizandar.varantmatik;

import android.app.*;
import android.content.*;
import android.os.Build;

public final class NotificationHelper {
    private static final String CH="radar";
    private NotificationHelper(){}
    public static void send(Context c,String title,String text,int id){
        NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);if(nm==null)return;
        if(Build.VERSION.SDK_INT>=26)nm.createNotificationChannel(new NotificationChannel(CH,"VarantMatik Nöbetçi",NotificationManager.IMPORTANCE_DEFAULT));
        Intent i=new Intent(c,MainActivity.class);PendingIntent pi=PendingIntent.getActivity(c,0,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(c,CH):new Notification.Builder(c);
        b.setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle(title).setContentText(text).setAutoCancel(true).setContentIntent(pi);
        nm.notify(id,b.build());
    }
}
