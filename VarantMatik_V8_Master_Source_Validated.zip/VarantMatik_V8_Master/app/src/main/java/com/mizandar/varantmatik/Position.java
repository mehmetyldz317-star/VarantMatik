package com.mizandar.varantmatik;

public final class Position {
    public final String symbol, direction, warrantCode, note;
    public final double underlyingEntry;
    public final long openedAt, expiryAt;
    public Position(String symbol,String direction,String warrantCode,double underlyingEntry,long openedAt,long expiryAt,String note){
        this.symbol=symbol;this.direction=direction;this.warrantCode=warrantCode;this.underlyingEntry=underlyingEntry;this.openedAt=openedAt;this.expiryAt=expiryAt;this.note=note;
    }
}
