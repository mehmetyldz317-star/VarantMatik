package com.mizandar.varantmatik.core;

import java.util.*;

public final class DivergenceDetector {
    private DivergenceDetector() {}

    public static Divergence detect(List<Candle> candles, double[] rsi, double atrLast) {
        if (candles.size()<35 || rsi.length!=candles.size()) return Divergence.none();
        List<Integer> lows=pivots(candles,true,2), highs=pivots(candles,false,2);
        Divergence bull = compareLastPair(candles,rsi,lows,true,atrLast);
        Divergence bear = compareLastPair(candles,rsi,highs,false,atrLast);
        if (bull.type==Divergence.Type.NONE) return bear;
        if (bear.type==Divergence.Type.NONE) return bull;
        return bull.secondIndex >= bear.secondIndex ? bull : bear;
    }

    private static List<Integer> pivots(List<Candle> c, boolean low, int radius) {
        List<Integer> out=new ArrayList<>();
        for(int i=radius;i<c.size()-radius;i++) {
            double v=low?c.get(i).low:c.get(i).high; boolean ok=true;
            for(int j=i-radius;j<=i+radius;j++) if(j!=i) {
                double q=low?c.get(j).low:c.get(j).high;
                if(low ? q<=v : q>=v){ ok=false; break; }
            }
            if(ok) out.add(i);
        }
        return out;
    }

    private static Divergence compareLastPair(List<Candle> c,double[] rsi,List<Integer> piv,boolean bull,double atrLast){
        if(piv.size()<2) return Divergence.none();
        for(int b=piv.size()-1;b>=1;b--) {
            int i2=piv.get(b);
            for(int a=b-1;a>=0;a--) {
                int i1=piv.get(a), dist=i2-i1;
                if(dist<5) continue;
                if(dist>60) break;
                double r1=rsi[i1], r2=rsi[i2]; if(Double.isNaN(r1)||Double.isNaN(r2)) continue;
                double p1=bull?c.get(i1).low:c.get(i1).high;
                double p2=bull?c.get(i2).low:c.get(i2).high;
                double minMove=Double.isNaN(atrLast)||atrLast<=0 ? Math.abs(p1)*0.0025 : atrLast*0.20;
                if(bull && p2 < p1-minMove && r2 > r1+2.0) {
                    double s=Math.min(1.0,((p1-p2)/Math.max(minMove,1e-9))*0.25 + ((r2-r1)/10.0)*0.5);
                    return new Divergence(Divergence.Type.BULLISH,i1,i2,p1,p2,r1,r2,s);
                }
                if(!bull && p2 > p1+minMove && r2 < r1-2.0) {
                    double s=Math.min(1.0,((p2-p1)/Math.max(minMove,1e-9))*0.25 + ((r1-r2)/10.0)*0.5);
                    return new Divergence(Divergence.Type.BEARISH,i1,i2,p1,p2,r1,r2,s);
                }
            }
        }
        return Divergence.none();
    }
}
