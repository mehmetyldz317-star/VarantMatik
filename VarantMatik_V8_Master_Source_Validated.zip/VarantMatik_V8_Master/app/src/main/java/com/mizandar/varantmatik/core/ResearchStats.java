package com.mizandar.varantmatik.core;

import java.util.*;

public final class ResearchStats {
    public static final int[] HORIZONS={1,3,5,10,20};
    public final int signalCount, strongCount;
    public final int[] samples,wins,baselineWins;
    public final double[] avgSignedReturn,medianSignedReturn,baselineAvgSignedReturn;
    public final double avgFavorable20,avgAdverse20;
    final List<Double>[] raw;
    final List<Double>[] baselineRaw;
    final double favorable20Sum,adverse20Sum;
    final int excursionN;

    ResearchStats(int signalCount,int strongCount,int[] samples,int[] wins,int[] baselineWins,
                  double[] avg,double[] median,double[] baselineAvg,double avgFav,double avgAdv,
                  List<Double>[] raw,List<Double>[] baselineRaw,double favorable20Sum,double adverse20Sum,int excursionN){
        this.signalCount=signalCount;this.strongCount=strongCount;
        this.samples=Arrays.copyOf(samples,samples.length);this.wins=Arrays.copyOf(wins,wins.length);this.baselineWins=Arrays.copyOf(baselineWins,baselineWins.length);
        this.avgSignedReturn=Arrays.copyOf(avg,avg.length);this.medianSignedReturn=Arrays.copyOf(median,median.length);this.baselineAvgSignedReturn=Arrays.copyOf(baselineAvg,baselineAvg.length);
        this.avgFavorable20=avgFav;this.avgAdverse20=avgAdv;this.raw=raw;this.baselineRaw=baselineRaw;
        this.favorable20Sum=favorable20Sum;this.adverse20Sum=adverse20Sum;this.excursionN=excursionN;
    }
    public double successPct(int i){return samples[i]==0?Double.NaN:wins[i]*100.0/samples[i];}
    public double baselineSuccessPct(int i){return samples[i]==0?Double.NaN:baselineWins[i]*100.0/samples[i];}

    public static ResearchStats merge(Collection<ResearchStats> all){
        Mutable m=new Mutable();
        for(ResearchStats s:all)m.merge(s);
        return m.freeze();
    }

    static final class Mutable {
        int signalCount,strongCount,excursionN;
        int[] samples=new int[HORIZONS.length],wins=new int[HORIZONS.length],baselineWins=new int[HORIZONS.length];
        double[] sums=new double[HORIZONS.length],baselineSums=new double[HORIZONS.length];
        double favorable20Sum,adverse20Sum;
        @SuppressWarnings("unchecked") List<Double>[] raw=new List[HORIZONS.length];
        @SuppressWarnings("unchecked") List<Double>[] baselineRaw=new List[HORIZONS.length];
        Mutable(){for(int i=0;i<HORIZONS.length;i++){raw[i]=new ArrayList<>();baselineRaw[i]=new ArrayList<>();}}
        void markSignal(boolean strong){signalCount++;if(strong)strongCount++;}
        void add(int k,double ret,double baselineRet){
            samples[k]++;sums[k]+=ret;raw[k].add(ret);if(ret>0)wins[k]++;
            baselineSums[k]+=baselineRet;baselineRaw[k].add(baselineRet);if(baselineRet>0)baselineWins[k]++;
        }
        void addExcursion(double fav,double adv){favorable20Sum+=fav;adverse20Sum+=adv;excursionN++;}
        void merge(ResearchStats s){
            signalCount+=s.signalCount;strongCount+=s.strongCount;excursionN+=s.excursionN;favorable20Sum+=s.favorable20Sum;adverse20Sum+=s.adverse20Sum;
            for(int i=0;i<HORIZONS.length;i++){
                samples[i]+=s.samples[i];wins[i]+=s.wins[i];baselineWins[i]+=s.baselineWins[i];
                for(double v:s.raw[i]){sums[i]+=v;raw[i].add(v);} for(double v:s.baselineRaw[i]){baselineSums[i]+=v;baselineRaw[i].add(v);}
            }
        }
        ResearchStats freeze(){
            double[] avg=new double[HORIZONS.length],med=new double[HORIZONS.length],bavg=new double[HORIZONS.length];
            for(int i=0;i<HORIZONS.length;i++){
                avg[i]=samples[i]==0?Double.NaN:sums[i]/samples[i];bavg[i]=samples[i]==0?Double.NaN:baselineSums[i]/samples[i];med[i]=median(raw[i]);
            }
            @SuppressWarnings("unchecked") List<Double>[] rawCopy=new List[HORIZONS.length];
            @SuppressWarnings("unchecked") List<Double>[] baseCopy=new List[HORIZONS.length];
            for(int i=0;i<HORIZONS.length;i++){rawCopy[i]=Collections.unmodifiableList(new ArrayList<>(raw[i]));baseCopy[i]=Collections.unmodifiableList(new ArrayList<>(baselineRaw[i]));}
            return new ResearchStats(signalCount,strongCount,samples,wins,baselineWins,avg,med,bavg,
                excursionN==0?Double.NaN:favorable20Sum/excursionN,excursionN==0?Double.NaN:adverse20Sum/excursionN,
                rawCopy,baseCopy,favorable20Sum,adverse20Sum,excursionN);
        }
        private static double median(List<Double> x){if(x.isEmpty())return Double.NaN;ArrayList<Double> a=new ArrayList<>(x);Collections.sort(a);int n=a.size();return n%2==1?a.get(n/2):(a.get(n/2-1)+a.get(n/2))/2.0;}
    }
}
