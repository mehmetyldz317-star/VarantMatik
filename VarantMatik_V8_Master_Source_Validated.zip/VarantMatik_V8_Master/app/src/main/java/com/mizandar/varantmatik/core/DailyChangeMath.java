package com.mizandar.varantmatik.core;

public final class DailyChangeMath {
    private DailyChangeMath(){}
    public static double percent(double current,double previousClose){
        if(!Double.isFinite(current)||!Double.isFinite(previousClose)||previousClose==0) return Double.NaN;
        return (current-previousClose)/previousClose*100.0;
    }
}
