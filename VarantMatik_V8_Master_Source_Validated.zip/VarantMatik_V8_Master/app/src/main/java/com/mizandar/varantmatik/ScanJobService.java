package com.mizandar.varantmatik;

import android.app.job.*;
import com.mizandar.varantmatik.core.*;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

public final class ScanJobService extends JobService {
    private final ExecutorService executor=Executors.newSingleThreadExecutor(); private Future<?> running;
    public boolean onStartJob(JobParameters p){running=executor.submit(()->{try{runScan();}finally{jobFinished(p,false);}});return true;}
    public boolean onStopJob(JobParameters p){if(running!=null)running.cancel(true);return true;}

    private void runScan(){
        if(!tradingWindow())return;
        AppStateStore st=new AppStateStore(this);LinkedHashSet<String> targets=new LinkedHashSet<>();targets.add("XU030");targets.add("DAX");targets.addAll(st.watchlist());for(Position p:st.positions())targets.add(p.symbol);
        int start=(st.rotation()%4)*8;for(int i=0;i<8;i++)targets.add(MarketUniverse.BIST30[(start+i)%MarketUniverse.BIST30.length]);st.rotation((st.rotation()+1)%4);
        MarketScanner scanner=new MarketScanner(this);
        for(String s:targets){if(Thread.currentThread().isInterrupted())return;try{RadarItem r=scanner.scanOne(s,false);String now=r.analysis.state.name(),old=st.previousState(s);if(!old.isEmpty()&&!old.equals(now)&&important(r.analysis.state))NotificationHelper.send(this,s+" durum değişti",r.analysis.label(),Math.abs(s.hashCode()));st.previousState(s,now);checkPositions(st,r);}catch(Exception ignored){}}
    }
    private void checkPositions(AppStateStore st,RadarItem r){
        for(Position p:st.positions())if(p.symbol.equals(r.analysis.symbol)){
            boolean opposite=("UP".equals(p.direction)&&r.analysis.state==MarketAnalysis.State.STRONG_DOWN)||("DOWN".equals(p.direction)&&r.analysis.state==MarketAnalysis.State.STRONG_UP);
            boolean invalid=false;
            if(!Double.isNaN(r.analysis.invalidation))invalid="UP".equals(p.direction)?r.analysis.price<r.analysis.invalidation:r.analysis.price>r.analysis.invalidation;
            String health=opposite?"OPPOSITE":invalid?"INVALID":"OK";
            String key=p.symbol+"_"+p.direction+"_"+(p.warrantCode==null?"":p.warrantCode);
            String previous=st.previousPositionHealth(key);
            if((opposite||invalid)&&!health.equals(previous))
                NotificationHelper.send(this,p.symbol+" pozisyon izle",opposite?"Teknik yön pozisyonun tersine güçlendi; pozisyonu gözden geçir.":"Dayanak senaryo bozulma seviyesini aştı; pozisyonu gözden geçir.",Math.abs((key+"pos").hashCode()));
            st.previousPositionHealth(key,health);
        }
    }
    private static boolean important(MarketAnalysis.State s){return s==MarketAnalysis.State.STRONG_UP||s==MarketAnalysis.State.STRONG_DOWN||s==MarketAnalysis.State.CONFIRM_UP||s==MarketAnalysis.State.CONFIRM_DOWN;}
    private static boolean tradingWindow(){ZonedDateTime z=ZonedDateTime.now(ZoneId.of("Europe/Istanbul"));int d=z.getDayOfWeek().getValue(),h=z.getHour();return d<=5&&h>=8&&h<=21;}
}
