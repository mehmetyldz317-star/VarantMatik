package com.mizandar.varantmatik.core;

import java.time.*;
import java.util.*;

/** Detailed walk-forward evaluator used by the BIST30 research laboratory. */
public final class ResearchBacktestEngine {
    private ResearchBacktestEngine(){}

    public static SymbolResearchReport run(String symbol,List<Candle> daily,List<Candle> h4,ZoneId zone,
                                           RegimeTimeline regimes,LocalDate holdoutStart){
        if(daily==null||daily.size()<240) throw new IllegalArgumentException("Araştırma için en az 240 günlük mum gerekli");
        if(h4==null||h4.size()<80) throw new IllegalArgumentException("Araştırma için yeterli 4 saat verisi yok");
        ResearchStats.Mutable all=new ResearchStats.Mutable(),up=new ResearchStats.Mutable(),down=new ResearchStats.Mutable();
        ResearchStats.Mutable bull=new ResearchStats.Mutable(),bear=new ResearchStats.Mutable(),sideways=new ResearchStats.Mutable();
        ResearchStats.Mutable dev=new ResearchStats.Mutable(),hold=new ResearchStats.Mutable(),strong=new ResearchStats.Mutable();
        double[] fullClose=Indicators.closes(daily), fullEma50=Indicators.ema(fullClose,50);
        LocalDate first4=Instant.ofEpochMilli(h4.get(0).time).atZone(zone).toLocalDate();
        int hEnd=-1,prevDir=0;long firstEval=0,lastEval=0;
        for(int i=220;i<daily.size();i++){
            LocalDate day=Instant.ofEpochMilli(daily.get(i).time).atZone(zone).toLocalDate();
            while(hEnd+1<h4.size()){
                LocalDate hd=Instant.ofEpochMilli(h4.get(hEnd+1).time).atZone(zone).toLocalDate();
                if(hd.isAfter(day))break;hEnd++;
            }
            if(day.isBefore(first4)||hEnd<40){prevDir=0;continue;}
            int ds=Math.max(0,i-319),hs=Math.max(0,hEnd-179);
            List<Candle>dSlice=daily.subList(ds,i+1),hSlice=h4.subList(hs,hEnd+1);
            double close=daily.get(i).close,change=i>0&&daily.get(i-1).close!=0?(close/daily.get(i-1).close-1.0)*100.0:Double.NaN;
            MarketAnalysis a=AnalysisEngine.analyze(symbol,dSlice,hSlice,close,change);
            int dir=direction(a.state);
            boolean member=Bist30Membership.isMember(symbol,day);
            if(member){if(firstEval==0)firstEval=daily.get(i).time;lastEval=daily.get(i).time;}
            if(member && dir!=0 && dir!=prevDir && i+1<daily.size() && daily.get(i+1).open>0){
                boolean isStrong=a.state==MarketAnalysis.State.STRONG_UP||a.state==MarketAnalysis.State.STRONG_DOWN;
                MarketRegime regime=regimes.on(day);
                ResearchStats.Mutable dirB=dir>0?up:down;
                ResearchStats.Mutable regB=regime==MarketRegime.BULL?bull:regime==MarketRegime.BEAR?bear:sideways;
                ResearchStats.Mutable segB=day.isBefore(holdoutStart)?dev:hold;
                ArrayList<ResearchStats.Mutable> buckets=new ArrayList<>(Arrays.asList(all,dirB,regB,segB));
                if(isStrong)buckets.add(strong);
                for(ResearchStats.Mutable b:buckets)b.markSignal(isStrong);
                double entry=daily.get(i+1).open;
                int baselineDir=(finite(fullEma50[i])&&close>=fullEma50[i])?1:-1;
                for(int k=0;k<ResearchStats.HORIZONS.length;k++){
                    int j=i+ResearchStats.HORIZONS[k];if(j>=daily.size())continue;
                    double rawRet=(daily.get(j).close/entry-1.0)*100.0;
                    double ret=dir*rawRet,base=baselineDir*rawRet;
                    for(ResearchStats.Mutable b:buckets)b.add(k,ret,base);
                }
                if(i+20<daily.size()){
                    double best=Double.NEGATIVE_INFINITY,worst=Double.POSITIVE_INFINITY;
                    for(int j=i+1;j<=i+20;j++){
                        Candle c=daily.get(j);double fav,adv;
                        if(dir>0){fav=(c.high/entry-1.0)*100.0;adv=(c.low/entry-1.0)*100.0;}
                        else{fav=(1.0-c.low/entry)*100.0;adv=(1.0-c.high/entry)*100.0;}
                        best=Math.max(best,fav);worst=Math.min(worst,adv);
                    }
                    for(ResearchStats.Mutable b:buckets)b.addExcursion(best,worst);
                }
            }
            prevDir=dir;
        }
        if(firstEval==0){firstEval=daily.get(daily.size()-1).time;lastEval=firstEval;}
        return new SymbolResearchReport(symbol,firstEval,lastEval,holdoutStart,
            all.freeze(),up.freeze(),down.freeze(),bull.freeze(),bear.freeze(),sideways.freeze(),dev.freeze(),hold.freeze(),strong.freeze());
    }
    private static int direction(MarketAnalysis.State s){return switch(s){case CONFIRM_UP,STRONG_UP->1;case CONFIRM_DOWN,STRONG_DOWN->-1;default->0;};}
    private static boolean finite(double x){return !Double.isNaN(x)&&!Double.isInfinite(x);}
}
