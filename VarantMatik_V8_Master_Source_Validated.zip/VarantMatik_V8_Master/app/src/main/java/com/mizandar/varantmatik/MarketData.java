package com.mizandar.varantmatik;

import com.mizandar.varantmatik.core.Candle;
import java.util.*;

public final class MarketData {
    public final List<Candle> candles;
    public final double livePrice;
    public final double changePct;
    public MarketData(List<Candle> candles,double livePrice,double changePct){ this.candles=candles;this.livePrice=livePrice;this.changePct=changePct; }
}
