package com.mizandar.varantmatik.core;

public final class WarrantMath {
    private WarrantMath() {}
    public enum Type { CALL, PUT }

    public static final class Result {
        public final double mid, spreadPct, intrinsic, timeValue, gearing, effectiveLeverage;
        public final String moneyness;
        Result(double mid,double spreadPct,double intrinsic,double timeValue,double gearing,double effectiveLeverage,String moneyness){
            this.mid=mid;this.spreadPct=spreadPct;this.intrinsic=intrinsic;this.timeValue=timeValue;this.gearing=gearing;this.effectiveLeverage=effectiveLeverage;this.moneyness=moneyness;
        }
    }

    /** ratio = one warrant's underlying entitlement, e.g. 0.1 underlying per warrant. */
    public static Result evaluate(Type type,double underlying,double strike,double bid,double ask,double ratio,double delta){
        if(underlying<=0||strike<=0||bid<0||ask<=0||ask<bid||ratio<=0) throw new IllegalArgumentException("Geçersiz varant girdisi");
        double mid=(bid+ask)/2.0;
        double spread=(ask-bid)/mid*100.0;
        double intrinsic=Math.max((type==Type.CALL?underlying-strike:strike-underlying)*ratio,0.0);
        double time=Math.max(mid-intrinsic,0.0);
        double gearing=underlying*ratio/mid;
        double eff=gearing*Math.abs(delta);
        String money;
        if(type==Type.CALL) money=underlying>strike?"Karda":underlying<strike?"Zararda":"Başabaş";
        else money=underlying<strike?"Karda":underlying>strike?"Zararda":"Başabaş";
        return new Result(mid,spread,intrinsic,time,gearing,eff,money);
    }
}
