package com.mizandar.varantmatik;

import android.content.Context;
import com.mizandar.varantmatik.core.Candle;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.time.*;
import java.util.*;

public final class YahooFinanceProvider {
    private final Context context;
    public YahooFinanceProvider(Context context){ this.context=context.getApplicationContext(); }

    public MarketData daily(String symbol, boolean force) throws Exception { return fetch(symbol,"1y","1d",20*60_000L,force); }
    public MarketData hourly(String symbol, boolean force) throws Exception { return fetch(symbol,"60d","60m",20*60_000L,force); }

    // Walk-forward doğrulama için daha uzun geçmiş. Yahoo intraday erişimi
    // sembole göre değişebildiği için 2y -> 1y -> 6mo geri dönüşü kullanılır.
    public MarketData historyDaily(String symbol, boolean force) throws Exception { return fetch(symbol,"5y","1d",6*60*60_000L,force); }
    public MarketData historyHourly(String symbol, boolean force) throws Exception {
        Exception last=null;
        for(String range:new String[]{"2y","1y","6mo"}){
            try{
                MarketData d=fetch(symbol,range,"60m",6*60*60_000L,force);
                if(d.candles.size()>=250)return d;
            }catch(Exception e){last=e;}
        }
        if(last!=null)throw last;
        throw new IOException("Uzun 60 dakikalık geçmiş alınamadı");
    }

    private MarketData fetch(String symbol,String range,String interval,long ttl,boolean force) throws Exception {
        String key=safe(symbol+"_"+range+"_"+interval)+".json";
        File f=new File(context.getCacheDir(),key);
        String json=null;
        if(!force && f.exists() && System.currentTimeMillis()-f.lastModified()<ttl) json=readFile(f);
        if(json==null){
            String encoded=URLEncoder.encode(MarketUniverse.yahoo(symbol), StandardCharsets.UTF_8.name()).replace("%5E","^");
            String path="/v8/finance/chart/"+encoded+"?range="+range+"&interval="+interval+"&includePrePost=false&events=div%2Csplits";
            Exception last=null;
            for(String host:new String[]{"query1.finance.yahoo.com","query2.finance.yahoo.com"}){
                try{ json=http("https://"+host+path); writeFile(f,json); last=null; break; }catch(Exception e){ last=e; }
            }
            if(json==null) throw last==null?new IOException("Veri alınamadı"):last;
        }
        return parse(symbol,json,interval);
    }

    private MarketData parse(String symbol,String json,String interval) throws Exception {
        JSONObject chart=new JSONObject(json).getJSONObject("chart");
        if(!chart.isNull("error")) throw new IOException(String.valueOf(chart.get("error")));
        JSONObject result=chart.getJSONArray("result").getJSONObject(0);
        JSONObject meta=result.getJSONObject("meta");
        double live=meta.optDouble("regularMarketPrice",Double.NaN);
        JSONArray ts=result.getJSONArray("timestamp");
        JSONObject q=result.getJSONObject("indicators").getJSONArray("quote").getJSONObject(0);
        JSONArray o=q.getJSONArray("open"),h=q.getJSONArray("high"),l=q.getJSONArray("low"),c=q.getJSONArray("close");
        JSONArray v=q.optJSONArray("volume"); ArrayList<Candle> out=new ArrayList<>(); long now=System.currentTimeMillis();
        ZoneId zone=MarketUniverse.zone(symbol); LocalDate today=Instant.ofEpochMilli(now).atZone(zone).toLocalDate();
        for(int i=0;i<ts.length();i++){
            if(o.isNull(i)||h.isNull(i)||l.isNull(i)||c.isNull(i)) continue;
            long t=ts.getLong(i)*1000L;
            if("60m".equals(interval) && now-t < 65*60_000L) continue;
            if("1d".equals(interval) && Instant.ofEpochMilli(t).atZone(zone).toLocalDate().equals(today)) {
                java.time.LocalTime lt=Instant.ofEpochMilli(now).atZone(zone).toLocalTime();
                java.time.LocalTime closeTime="DAX".equals(symbol)?java.time.LocalTime.of(17,45):java.time.LocalTime.of(18,15);
                if(lt.isBefore(closeTime)) continue;
            }
            double vol=(v==null||v.isNull(i))?0:v.optDouble(i,0);
            out.add(new Candle(t,o.getDouble(i),h.getDouble(i),l.getDouble(i),c.getDouble(i),vol));
        }
        // Günlük değişimi Yahoo meta.chartPreviousClose üzerinden hesaplamıyoruz.
        // Bu alan uzun range (örn. 1y) çağrılarında grafik aralığının öncesindeki
        // kapanışı gösterebilir ve günlük yüzde yerine 1 yıllık getiri üretebilir.
        // Referans kapanış, tamamlanmış günlük mumlardan türetilir.
        double change=Double.NaN;
        if("1d".equals(interval) && !out.isEmpty()){
            int last=out.size()-1;
            LocalDate lastDate=Instant.ofEpochMilli(out.get(last).time).atZone(zone).toLocalDate();
            double current=!Double.isNaN(live)?live:out.get(last).close;
            double refClose=Double.NaN;
            if(lastDate.equals(today)){
                // Piyasa kapandıktan sonra bugünün mumu listeye dahildir; önceki seansı baz al.
                if(last>=1) refClose=out.get(last-1).close;
                current=out.get(last).close;
            }else{
                // Piyasa açıkken son mum dünkü tamamlanmış seanstır; canlı fiyatı onunla kıyasla.
                refClose=out.get(last).close;
            }
            if(!Double.isNaN(current)&&!Double.isNaN(refClose)&&refClose!=0) change=com.mizandar.varantmatik.core.DailyChangeMath.percent(current,refClose);
        }
        return new MarketData(out,live,change);
    }

    private String http(String u) throws Exception {
        Exception last=null;
        for(int attempt=0;attempt<3;attempt++){
            HttpURLConnection c=(HttpURLConnection)new URL(u).openConnection();
            try{
                c.setRequestMethod("GET");c.setConnectTimeout(10000);c.setReadTimeout(25000);
                c.setRequestProperty("User-Agent","Mozilla/5.0 (Android; VarantMatik-Research/1.2)");
                int code=c.getResponseCode(); InputStream in=code>=200&&code<300?c.getInputStream():c.getErrorStream();
                String text=readAll(in);
                if(code>=200&&code<300)return text;
                IOException ex=new IOException("HTTP "+code);last=ex;
                if(code!=429 && code<500)throw ex;
            }catch(Exception e){last=e;}finally{c.disconnect();}
            try{Thread.sleep(700L*(attempt+1));}catch(InterruptedException ie){Thread.currentThread().interrupt();throw ie;}
        }
        throw last==null?new IOException("HTTP veri alınamadı"):last;
    }
    private static String readAll(InputStream in)throws Exception{if(in==null)return"";StringBuilder s=new StringBuilder();try(BufferedReader b=new BufferedReader(new InputStreamReader(in,StandardCharsets.UTF_8))){String x;while((x=b.readLine())!=null)s.append(x);}return s.toString();}
    private static String readFile(File f)throws Exception{try(FileInputStream in=new FileInputStream(f)){byte[] b=new byte[(int)f.length()];int off=0,n;while(off<b.length&&(n=in.read(b,off,b.length-off))>0)off+=n;return new String(b,0,off,StandardCharsets.UTF_8);}}
    private static void writeFile(File f,String s){try(FileOutputStream o=new FileOutputStream(f)){o.write(s.getBytes(StandardCharsets.UTF_8));}catch(Exception ignored){}}
    private static String safe(String s){return s.replaceAll("[^A-Za-z0-9_.-]","_");}
}
