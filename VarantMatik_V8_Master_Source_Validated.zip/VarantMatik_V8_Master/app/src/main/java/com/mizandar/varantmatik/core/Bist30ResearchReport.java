package com.mizandar.varantmatik.core;

import java.time.LocalDate;
import java.util.*;

public final class Bist30ResearchReport {
    public final List<SymbolResearchReport> symbols;
    public final List<String> failures;
    public final LocalDate holdoutStart;
    public final ResearchStats all,up,down,bull,bear,sideways,development,holdout,strong;

    public Bist30ResearchReport(List<SymbolResearchReport> symbols,List<String> failures,LocalDate holdoutStart){
        this.symbols=Collections.unmodifiableList(new ArrayList<>(symbols));this.failures=Collections.unmodifiableList(new ArrayList<>(failures));this.holdoutStart=holdoutStart;
        this.all=merge(symbols,"all");this.up=merge(symbols,"up");this.down=merge(symbols,"down");
        this.bull=merge(symbols,"bull");this.bear=merge(symbols,"bear");this.sideways=merge(symbols,"sideways");
        this.development=merge(symbols,"development");this.holdout=merge(symbols,"holdout");this.strong=merge(symbols,"strong");
    }
    private static ResearchStats merge(List<SymbolResearchReport> x,String field){
        ArrayList<ResearchStats> a=new ArrayList<>();for(SymbolResearchReport r:x){switch(field){
            case "up"->a.add(r.up);case "down"->a.add(r.down);case "bull"->a.add(r.bull);case "bear"->a.add(r.bear);case "sideways"->a.add(r.sideways);
            case "development"->a.add(r.development);case "holdout"->a.add(r.holdout);case "strong"->a.add(r.strong);default->a.add(r.all);
        }}return ResearchStats.merge(a);
    }
}
