package com.mizandar.varantmatik;
import android.content.*;
public final class BootReceiver extends BroadcastReceiver { public void onReceive(Context c,Intent i){BackgroundScheduler.apply(c);} }
