package com.mizandar.varantmatik.core;

import java.time.LocalDate;
import java.util.*;

/**
 * Point-in-time BIST30 membership for the research window supported by the
 * 60-minute Yahoo history used by VarantMatik (roughly two years).
 *
 * The sets are reconstructed from Borsa Istanbul's quarterly index-review
 * announcements. Research must never apply today's constituents to older
 * dates silently, because that creates survivorship bias.
 */
public final class Bist30Membership {
    private Bist30Membership() {}

    private static final Set<String> Q3_2026 = set(
        "AEFES","AKBNK","ASELS","ASTOR","BIMAS","DSTKF","EKGYO","ENKAI","EREGL","FROTO",
        "GARAN","GUBRF","ISCTR","KCHOL","KRDMD","MGROS","PETKM","PGSUS","SAHOL","SASA",
        "SISE","TAVHL","TCELL","THYAO","TOASO","TRALT","TTKOM","TUPRS","VAKBN","YKBNK"
    );
    private static final Set<String> Q2_2026 = Q3_2026;
    private static final Set<String> Q1_2026 = replace(Q2_2026, new String[]{"VAKBN"}, new String[]{"ULKER"});
    private static final Set<String> Q4_2025 = Q1_2026; // Q1 2026 review: no BIST30 constituent change.
    private static final Set<String> Q3_2025 = replace(Q4_2025, new String[]{"DSTKF"}, new String[]{"CIMSA"});
    private static final Set<String> Q2_2025 = replace(Q3_2025, new String[]{"GUBRF"}, new String[]{"HEKTS"});
    private static final Set<String> Q1_2025 = replace(Q2_2025, new String[]{"CIMSA","TAVHL"}, new String[]{"ALARK","KONTR"});
    private static final Set<String> Q4_2024 = replace(Q1_2025, new String[]{"AEFES"}, new String[]{"DOAS"});
    private static final Set<String> Q4_2026 = replace(Q3_2026, new String[]{"DSTKF"}, new String[]{"TRMET"});

    /** Actual/announced effective boundaries used by the research engine. */
    public static Set<String> members(LocalDate d) {
        if (d == null) return Collections.emptySet();
        if (!d.isBefore(LocalDate.of(2026,10,1))) return Q4_2026;
        if (!d.isBefore(LocalDate.of(2026,7,1))) return Q3_2026;
        if (!d.isBefore(LocalDate.of(2026,4,1))) return Q2_2026;
        if (!d.isBefore(LocalDate.of(2026,1,1))) return Q1_2026;
        if (!d.isBefore(LocalDate.of(2025,10,1))) return Q4_2025;
        if (!d.isBefore(LocalDate.of(2025,7,1))) return Q3_2025;
        // 2025 Q2 changes became effective after the holiday on 2 April.
        if (!d.isBefore(LocalDate.of(2025,4,2))) return Q2_2025;
        // 2025 Q1 changes became effective on 2 January.
        if (!d.isBefore(LocalDate.of(2025,1,2))) return Q1_2025;
        if (!d.isBefore(LocalDate.of(2024,10,1))) return Q4_2024;
        return Collections.emptySet();
    }

    public static boolean isMember(String symbol, LocalDate d) {
        return symbol != null && members(d).contains(symbol);
    }

    /** Union of all constituents needed to remove survivorship bias in Oct-2024 onward research. */
    public static List<String> researchSymbols() {
        TreeSet<String> all = new TreeSet<>();
        for (Set<String> s : Arrays.asList(Q4_2024,Q1_2025,Q2_2025,Q3_2025,Q4_2025,Q1_2026,Q2_2026,Q3_2026)) all.addAll(s);
        return new ArrayList<>(all);
    }

    public static Set<String> currentQ3_2026() { return Q3_2026; }

    private static Set<String> set(String... a) {
        LinkedHashSet<String> s = new LinkedHashSet<>(Arrays.asList(a));
        if (s.size()!=30) throw new IllegalStateException("BIST30 set size="+s.size());
        return Collections.unmodifiableSet(s);
    }

    private static Set<String> replace(Set<String> base, String[] remove, String[] add) {
        LinkedHashSet<String> s = new LinkedHashSet<>(base);
        for (String x:remove) s.remove(x);
        s.addAll(Arrays.asList(add));
        if (s.size()!=30) throw new IllegalStateException("BIST30 reconstructed set size="+s.size());
        return Collections.unmodifiableSet(s);
    }
}
