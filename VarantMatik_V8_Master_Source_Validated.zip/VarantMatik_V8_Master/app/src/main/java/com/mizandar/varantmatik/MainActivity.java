package com.mizandar.varantmatik;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.mizandar.varantmatik.core.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,16,28), PANEL=Color.rgb(15,27,45), PANEL2=Color.rgb(20,35,57);
    private static final int TEXT=Color.rgb(238,244,252), MUTED=Color.rgb(150,168,190), GREEN=Color.rgb(55,205,130), RED=Color.rgb(239,102,102), YELLOW=Color.rgb(239,200,79), BLUE=Color.rgb(91,157,255);
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final DecimalFormat d2=new DecimalFormat("0.00");
    private MarketScanner scanner;
    private Spinner symbolSpinner;
    private Button analyzeButton, warrantsButton, evaluateButton;
    private LinearLayout resultBox;
    private TextView status;
    private RadarItem last;

    private static final String[] SYMBOLS={"XU030","DAX","THYAO","ASELS","BIMAS"};

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        scanner=new MarketScanner(this);
        setContentView(build());
    }

    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();}

    private View build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(18),dp(18),dp(28));
        root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(dp(18),in.getSystemWindowInsetTop()+dp(14),dp(18),in.getSystemWindowInsetBottom()+dp(20));return in;});

        root.addView(tv("VarantMatik Lite",30,GREEN,true));
        TextView sub=tv("Dayanağı seç • analiz et • sonra varanta geç",14,MUTED,false);sub.setPadding(0,dp(2),0,dp(18));root.addView(sub);

        LinearLayout pick=panel();
        pick.addView(tv("1  DAYANAK SEÇ",12,MUTED,true));
        symbolSpinner=new Spinner(this);
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,SYMBOLS){
            @Override public View getView(int p,View c,android.view.ViewGroup parent){TextView v=(TextView)super.getView(p,c,parent);v.setTextColor(TEXT);v.setTextSize(20);v.setPadding(dp(8),dp(12),dp(8),dp(12));return v;}
            @Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(p,c,parent);v.setTextColor(Color.BLACK);v.setTextSize(18);return v;}
        };
        symbolSpinner.setAdapter(ad);pick.addView(symbolSpinner,new LinearLayout.LayoutParams(-1,dp(58)));
        analyzeButton=button("ANALİZ ET",GREEN);analyzeButton.setOnClickListener(v->analyze());pick.addView(analyzeButton,new LinearLayout.LayoutParams(-1,dp(52)));
        root.addView(pick);

        status=tv("Hazır",12,MUTED,false);status.setPadding(dp(4),dp(4),0,dp(8));root.addView(status);

        resultBox=panel();resultBox.addView(tv("2  ANALİZ SONUCU",12,MUTED,true));resultBox.addView(tv("Bir dayanak seçip ANALİZ ET'e bas.",14,TEXT,false));root.addView(resultBox);

        LinearLayout w=panel();w.addView(tv("3  VARANTA GEÇ",12,MUTED,true));
        w.addView(tv("Yön oluşmadan varant seçmiyoruz. Önce dayanak, sonra teyit, en son varant.",13,TEXT,false));
        warrantsButton=button("VARANTLARI GÖR",BLUE);warrantsButton.setEnabled(false);warrantsButton.setOnClickListener(v->openWarrants());w.addView(warrantsButton,new LinearLayout.LayoutParams(-1,dp(50)));
        evaluateButton=button("SEÇTİĞİM VARANTI DEĞERLENDİR",PANEL2);evaluateButton.setOnClickListener(v->warrantDialog());w.addView(evaluateButton,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView delayed=tv("Varant listesi dış kaynaktan açılır; kamuya açık listede veriler yaklaşık 15 dakika gecikmeli olabilir.",11,MUTED,false);delayed.setPadding(0,dp(8),0,0);w.addView(delayed);
        root.addView(w);

        TextView note=tv("Bu uygulama emir üretmez. Teknik koşulları sadeleştirir; varantlarda kaldıraç, zaman değeri ve toplam prim kaybı riski vardır.",11,YELLOW,false);note.setPadding(dp(4),dp(6),dp(4),0);root.addView(note);
        scroll.addView(root);return scroll;
    }

    private void analyze(){
        final String s=String.valueOf(symbolSpinner.getSelectedItem());
        analyzeButton.setEnabled(false);warrantsButton.setEnabled(false);last=null;
        status.setText(s+" • günlük + 4 saat verisi yükleniyor…");status.setTextColor(YELLOW);
        executor.execute(()->{
            try{
                RadarItem r=scanner.scanOne(s,true);
                ui.post(()->{last=r;analyzeButton.setEnabled(true);render(r);status.setText("Analiz tamamlandı • "+now());status.setTextColor(GREEN);});
            }catch(Exception e){
                ui.post(()->{analyzeButton.setEnabled(true);status.setText("Veri alınamadı: "+safe(e.getMessage()));status.setTextColor(RED);});
            }
        });
    }

    private void render(RadarItem r){
        resultBox.removeAllViews();resultBox.addView(tv("2  ANALİZ SONUCU",12,MUTED,true));
        MarketAnalysis a=r.analysis;
        resultBox.addView(tv(a.symbol+"   "+fmt(a.price),25,TEXT,true));
        resultBox.addView(tv("Günlük "+pct(a.changePct),14,Double.isNaN(a.changePct)?MUTED:(a.changePct>=0?GREEN:RED),true));
        TextView state=tv(a.label(),17,stateColor(a.state),true);state.setPadding(dp(12),dp(10),dp(12),dp(10));state.setBackground(pill(PANEL2,14));resultBox.addView(state);
        resultBox.addView(tv("Günlük RSI: "+fmt(a.rsiDaily)+"   •   4S RSI: "+fmt(a.rsi4h),13,TEXT,false));
        resultBox.addView(tv("Destek: "+fmt(a.support)+"   •   Direnç: "+fmt(a.resistance),13,MUTED,false));
        resultBox.addView(tv("Senaryo bozulma: "+fmt(a.invalidation),12,MUTED,false));
        if(!a.reasons.isEmpty()){
            resultBox.addView(tv("Neden?",13,TEXT,true));
            int n=Math.min(4,a.reasons.size()); for(int i=0;i<n;i++) resultBox.addView(tv("• "+a.reasons.get(i),12,TEXT,false));
        }
        String action;
        if(isUp(a.state)) action="Yukarı yönlü (CALL) varantları inceleyebilirsin; henüz otomatik seçim yok.";
        else if(isDown(a.state)) action="Aşağı yönlü (PUT) varantları inceleyebilirsin; henüz otomatik seçim yok.";
        else action="Yön net değil. Varant açmak yerine dayanağı izlemek daha tutarlı.";
        TextView next=tv(action,13,isUp(a.state)?GREEN:isDown(a.state)?RED:YELLOW,true);next.setPadding(0,dp(10),0,0);resultBox.addView(next);
        warrantsButton.setEnabled(a.state!=MarketAnalysis.State.WAIT);
    }

    private void openWarrants(){
        String url="https://www.garantibbvayatirim.com.tr/varant/varant-pusulasi";
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}
        catch(Exception e){Toast.makeText(this,"Tarayıcı açılamadı",Toast.LENGTH_SHORT).show();}
    }

    private void warrantDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(4),dp(12),0);
        EditText code=input("Varant kodu (örn. ABCDE)");
        EditText days=input("Vadeye kalan gün");days.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText bid=input("P.Y. alış");bid.setInputType(8194);
        EditText ask=input("P.Y. satış");ask.setInputType(8194);
        EditText delta=input("Delta (örn. 0.45)");delta.setInputType(8194);
        EditText leverage=input("Etkin kaldıraç (örn. 5.2)");leverage.setInputType(8194);
        for(EditText e:new EditText[]{code,days,bid,ask,delta,leverage})box.addView(e);
        new AlertDialog.Builder(this).setTitle("Varant teknik filtresi").setView(box).setNegativeButton("İptal",null).setPositiveButton("DEĞERLENDİR",(d,w)->{
            try{
                String c=code.getText().toString().trim().toUpperCase(Locale.ROOT);
                int day=Integer.parseInt(days.getText().toString().trim());
                double b=Double.parseDouble(bid.getText().toString().replace(',','.'));
                double a=Double.parseDouble(ask.getText().toString().replace(',','.'));
                double de=Math.abs(Double.parseDouble(delta.getText().toString().replace(',','.')));
                double lev=Double.parseDouble(leverage.getText().toString().replace(',','.'));
                if(a<=0||b<0||a<b)throw new IllegalArgumentException();
                double mid=(a+b)/2.0, spread=(a-b)/mid*100.0;
                showWarrantResult(c,day,spread,de,lev);
            }catch(Exception ex){Toast.makeText(this,"Girdileri kontrol et",Toast.LENGTH_LONG).show();}
        }).show();
    }

    private void showWarrantResult(String code,int days,double spread,double delta,double lev){
        ArrayList<String> lines=new ArrayList<>();
        lines.add("Makas: %"+d2.format(spread)+(spread<=3?" • dar":spread<=6?" • orta":" • geniş"));
        lines.add("Vade: "+days+" gün"+(days>=45?" • rahat":days>=20?" • dikkat":" • zaman değeri riski yüksek"));
        lines.add("Delta: "+d2.format(delta)+(delta>=0.35&&delta<=0.70?" • orta hassasiyet":delta<0.25?" • düşük hassasiyet":" • yüksek hassasiyet"));
        lines.add("Etkin kaldıraç: "+d2.format(lev));
        int flags=0;if(spread>6)flags++;if(days<20)flags++;if(delta<0.20)flags++;if(lev>10)flags++;
        String head=flags==0?"Belirgin yapısal uyarı yok":flags==1?"1 yapısal uyarı var":flags+" yapısal uyarı var";
        new AlertDialog.Builder(this).setTitle((code.isEmpty()?"Varant":code)+" • "+head).setMessage(String.join("\n",lines)+"\n\nBu sonuç al/sat önerisi değildir; yalnız varantın yapısal özelliklerini özetler.").setPositiveButton("Tamam",null).show();
    }

    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(8),dp(9),dp(8),dp(9));return e;}
    private LinearLayout panel(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(14),dp(16),dp(14));x.setBackground(pill(PANEL,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(14));x.setLayoutParams(lp);return x;}
    private TextView tv(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(sp);v.setLineSpacing(0,1.08f);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private Button button(String s,int bg){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(pill(bg,16));return b;}
    private GradientDrawable pill(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)r));return g;}
    private int stateColor(MarketAnalysis.State s){if(isUp(s))return GREEN;if(isDown(s))return RED;return YELLOW;}
    private boolean isUp(MarketAnalysis.State s){return s==MarketAnalysis.State.WATCH_UP||s==MarketAnalysis.State.CONFIRM_UP||s==MarketAnalysis.State.STRONG_UP;}
    private boolean isDown(MarketAnalysis.State s){return s==MarketAnalysis.State.WATCH_DOWN||s==MarketAnalysis.State.CONFIRM_DOWN||s==MarketAnalysis.State.STRONG_DOWN;}
    private String fmt(double x){return Double.isNaN(x)?"—":d2.format(x);}
    private String pct(double x){return Double.isNaN(x)?"—":(x>=0?"+":"")+d2.format(x)+"%";}
    private String now(){return new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.forLanguageTag("tr-TR")).format(new Date());}
    private String safe(String s){if(s==null||s.isBlank())return "veri hatası";s=s.replace('\n',' ').replace('\r',' ');return s.length()>60?s.substring(0,60)+"…":s;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
