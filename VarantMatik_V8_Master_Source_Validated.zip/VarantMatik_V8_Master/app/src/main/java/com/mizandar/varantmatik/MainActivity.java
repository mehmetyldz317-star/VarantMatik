package com.mizandar.varantmatik;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.*;
import android.graphics.drawable.GradientDrawable;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.mizandar.varantmatik.core.*;
import java.text.*;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,16,28), PANEL=Color.rgb(15,27,45), PANEL2=Color.rgb(20,35,57);
    private static final int TEXT=Color.rgb(238,244,252), MUTED=Color.rgb(150,168,190), GREEN=Color.rgb(55,205,130), RED=Color.rgb(239,102,102), YELLOW=Color.rgb(239,200,79), BLUE=Color.rgb(91,157,255);
    private final ExecutorService executor=Executors.newSingleThreadExecutor(); private final Handler ui=new Handler(Looper.getMainLooper());
    private AppStateStore store; private MarketScanner scanner; private LinearLayout content; private TextView status,lastScan; private Button fullScan; private String tab="RADAR";
    private final LinkedHashMap<String,RadarItem> latest=new LinkedHashMap<>();
    private int lastRequested=MarketUniverse.all().size();
    private final ArrayList<String> lastFailures=new ArrayList<>();

    @Override public void onCreate(Bundle b){super.onCreate(b);getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);store=new AppStateStore(this);scanner=new MarketScanner(this);setContentView(build());requestNotification();BackgroundScheduler.apply(this);quickOpen();}
    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();}

    private View build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(16),dp(10),dp(16),0);
        root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(dp(16),in.getSystemWindowInsetTop()+dp(8),dp(16),in.getSystemWindowInsetBottom());return in;});
        LinearLayout head=new LinearLayout(this);head.setOrientation(LinearLayout.HORIZONTAL);head.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout titles=new LinearLayout(this);titles.setOrientation(LinearLayout.VERTICAL);titles.addView(tv("VarantMatik V8.1",27,GREEN,true));titles.addView(tv("Swing / pozisyon nöbetçisi",12,MUTED,false));head.addView(titles,new LinearLayout.LayoutParams(0,-2,1));
        fullScan=button("TAM TARAMA",GREEN);fullScan.setOnClickListener(v->fullScan(false));head.addView(fullScan,new LinearLayout.LayoutParams(dp(126),dp(46)));root.addView(head);
        TextView motto=tv("Hız değil doğruluk • önce dayanak • sonra teyit • en son varant",12,TEXT,false);motto.setPadding(0,dp(10),0,dp(8));root.addView(motto);
        status=tv("Hazır",12,MUTED,false);lastScan=tv("Son tarama: —",11,MUTED,false);root.addView(status);root.addView(lastScan);
        LinearLayout tabs=new LinearLayout(this);tabs.setOrientation(LinearLayout.HORIZONTAL);tabs.setPadding(0,dp(10),0,dp(8));for(String x:new String[]{"RADAR","İZLEME","POZİSYON","NÖBETÇİ"}){Button b=button(x,PANEL2);b.setTextSize(10);b.setOnClickListener(v->{tab=((Button)v).getText().toString();renderTab();});tabs.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));}root.addView(tabs);
        ScrollView sv=new ScrollView(this);content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);content.setPadding(0,0,0,dp(28));sv.addView(content);root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));return root;
    }

    private void quickOpen(){status("XU030 ve DAX yükleniyor…",YELLOW);executor.execute(()->{for(String s:new String[]{"XU030","DAX"}){try{RadarItem r=scanner.scanOne(s,false);latest.put(s,r);}catch(Exception ignored){}}ui.post(()->{status("Hazır • tam BIST30 için Tam Tarama",GREEN);lastScan.setText("Hızlı tarama: "+now());renderTab();});});}

    private void fullScan(boolean force){fullScan.setEnabled(false);status("BIST30 taraması başlıyor…",YELLOW);Set<String> priority=new LinkedHashSet<>(store.watchlist());for(Position p:store.positions())priority.add(p.symbol);executor.execute(()->{try{ScanResult result=scanner.fullScan(priority,force,t->ui.post(()->status(t,YELLOW)));ui.post(()->{latest.clear();for(RadarItem r:result.items)latest.put(r.analysis.symbol,r);lastRequested=result.requested;lastFailures.clear();lastFailures.addAll(result.failures);fullScan.setEnabled(true);int miss=Math.max(0,result.requested-result.items.size());status("Tarama tamamlandı • "+result.items.size()+"/"+result.requested+" dayanak"+(miss>0?" • "+miss+" veri eksik":""),miss>0?YELLOW:GREEN);lastScan.setText("Son tarama: "+now());renderTab();});}catch(Exception e){ui.post(()->{fullScan.setEnabled(true);status("Tarama tamamlanamadı: "+safe(e.getMessage()),RED);});}});}

    private void renderTab(){content.removeAllViews();switch(tab){case "İZLEME"->renderWatch();case "POZİSYON"->renderPositions();case "NÖBETÇİ"->renderGuard();default->renderRadar();}}
    private void renderRadar(){
        if(latest.isEmpty()){empty("Henüz radar verisi yok. Hızlı tarama otomatik gelir; BIST30 için TAM TARAMA'ya bas.");return;}
        int strong=0,confirm=0;for(RadarItem r:latest.values()){if(r.analysis.state==MarketAnalysis.State.STRONG_UP||r.analysis.state==MarketAnalysis.State.STRONG_DOWN)strong++;if(r.analysis.state==MarketAnalysis.State.CONFIRM_UP||r.analysis.state==MarketAnalysis.State.CONFIRM_DOWN)confirm++;}
        LinearLayout summary=panel();summary.addView(tv("Piyasa Özeti",16,TEXT,true));summary.addView(tv(strong+" güçlü koşul • "+confirm+" teyit gelişiyor • "+latest.size()+"/"+lastRequested+" taranan",12,MUTED,false));if(!lastFailures.isEmpty())summary.addView(tv("Veri eksik: "+String.join(", ",lastFailures.subList(0,Math.min(5,lastFailures.size())))+(lastFailures.size()>5?" …":""),10,YELLOW,false));content.addView(summary);
        int shown=0;for(RadarItem r:latest.values()){content.addView(card(r));if(++shown>=18)break;}if(latest.size()>shown)content.addView(tv("İlk "+shown+" aday gösteriliyor. İzleme listesi öncelikli taranır.",11,MUTED,false));
    }
    private void renderWatch(){Set<String>w=store.watchlist();if(w.isEmpty()){empty("İzleme listen boş. Radar kartındaki İZLE düğmesiyle aday ekleyebilirsin.");return;}for(String s:w){RadarItem r=latest.get(s);if(r!=null)content.addView(card(r));else{LinearLayout p=panel();p.addView(tv(s,18,TEXT,true));p.addView(tv("Sonuç henüz bellekte yok. Tam taramada öncelikli kontrol edilir.",11,MUTED,false));content.addView(p);}}}
    private void renderPositions(){
        Button add=button("+ POZİSYON KAYDI EKLE",BLUE);add.setOnClickListener(v->positionDialog());content.addView(add,new LinearLayout.LayoutParams(-1,dp(48)));
        List<Position> ps=store.positions();if(ps.isEmpty()){empty("Açık pozisyon kaydı yok. Pozisyon kaydı; dayanak senaryosunu, geçen süreyi ve vade riskini takip etmek içindir.");return;}
        for(int i=0;i<ps.size();i++){final int idx=i;Position p=ps.get(i);LinearLayout box=panel();box.addView(tv(p.symbol+" • "+("UP".equals(p.direction)?"Yukarı senaryo":"Aşağı senaryo"),17,TEXT,true));box.addView(tv("Varant: "+(p.warrantCode.isEmpty()?"—":p.warrantCode)+" • Dayanak giriş: "+fmt(p.underlyingEntry),12,MUTED,false));long days=p.expiryAt>0?Math.max(0,(p.expiryAt-System.currentTimeMillis())/86400000L):-1;box.addView(tv("Pozisyonda: "+Math.max(0,(System.currentTimeMillis()-p.openedAt)/86400000L)+" gün"+(days>=0?" • Vade: "+days+" gün":""),12,days>=0&&days<30?RED:MUTED,false));RadarItem r=latest.get(p.symbol);if(r!=null){String health=positionHealth(p,r.analysis);box.addView(tv(health,13,health.contains("ZAYIF")?RED:health.contains("ÇIKIŞ")?YELLOW:GREEN,true));}Button del=button("KAYDI KAPAT",PANEL2);del.setOnClickListener(v->{store.removePosition(idx);renderPositions();});box.addView(del,new LinearLayout.LayoutParams(-1,dp(40)));content.addView(box);}
    }
    private void renderGuard(){
        LinearLayout p=panel();p.addView(tv("Sessiz Nöbetçi",19,TEXT,true));p.addView(tv("Uygulama açık olmasa da Android JobScheduler periyodik kontrol ister. Android bu süreyi tam dakika garantisiyle çalıştırmaz.",12,MUTED,false));
        Switch sw=new Switch(this);sw.setText(store.guardEnabled()?"Nöbetçi açık":"Nöbetçi kapalı");sw.setTextColor(TEXT);sw.setChecked(store.guardEnabled());p.addView(sw);
        TextView info=tv("Tarama aralığı: "+store.guardMinutes()+" dk",13,TEXT,true);p.addView(info);
        LinearLayout row=new LinearLayout(this);for(int m:new int[]{15,30,60}){Button b=button(m+" dk",PANEL2);b.setOnClickListener(v->{store.setGuard(sw.isChecked(),m);BackgroundScheduler.apply(this);info.setText("Tarama aralığı: "+m+" dk");});row.addView(b,new LinearLayout.LayoutParams(0,dp(44),1));}p.addView(row);sw.setOnCheckedChangeListener((b,on)->{store.setGuard(on,store.guardMinutes());BackgroundScheduler.apply(this);sw.setText(on?"Nöbetçi açık":"Nöbetçi kapalı");});
        p.addView(tv("Bildirim yalnız önemli durum değişimlerinde gönderilir: teyit/güçlü koşul veya kayıtlı pozisyonda teknik senaryo zayıflaması. Her RSI değişiminde bildirim yok.",11,MUTED,false));content.addView(p);
    }

    private View card(RadarItem r){MarketAnalysis a=r.analysis;LinearLayout box=panel();LinearLayout top=new LinearLayout(this);top.setGravity(Gravity.CENTER_VERTICAL);LinearLayout left=new LinearLayout(this);left.setOrientation(LinearLayout.VERTICAL);left.addView(tv(a.symbol,20,TEXT,true));left.addView(tv(fmt(a.price)+"   Günlük "+pct(a.changePct),13,Double.isNaN(a.changePct)?MUTED:(a.changePct>=0?GREEN:RED),true));top.addView(left,new LinearLayout.LayoutParams(0,-2,1));TextView state=tv(a.label(),11,stateColor(a.state),true);state.setPadding(dp(10),dp(7),dp(10),dp(7));state.setBackground(pill(PANEL2,12));top.addView(state);box.addView(top);
        MiniChartView chart=new MiniChartView(this);chart.setCandles(r.daily);box.addView(chart,new LinearLayout.LayoutParams(-1,dp(92)));
        box.addView(tv("Günlük RSI "+fmt(a.rsiDaily)+"  •  4S RSI "+fmt(a.rsi4h)+"  •  Teyit "+a.alignedChecks,11,MUTED,false));box.addView(tv("Destek "+fmt(a.support)+"  •  Direnç "+fmt(a.resistance)+(Double.isNaN(a.invalidation)?"":"  •  Senaryo bozulma "+fmt(a.invalidation)),11,MUTED,false));
        if(!a.reasons.isEmpty())box.addView(tv("• "+String.join("  •  ",a.reasons.subList(0,Math.min(3,a.reasons.size()))),11,TEXT,false));
        LinearLayout actions=new LinearLayout(this);Button watch=button(store.watched(a.symbol)?"İZLEMEDEN ÇIK":"İZLE",PANEL2);watch.setOnClickListener(v->{store.toggleWatch(a.symbol);((Button)v).setText(store.watched(a.symbol)?"İZLEMEDEN ÇIK":"İZLE");});Button detail=button("DETAY",PANEL2);detail.setOnClickListener(v->detailDialog(r));actions.addView(watch,new LinearLayout.LayoutParams(0,dp(40),1));actions.addView(detail,new LinearLayout.LayoutParams(0,dp(40),1));box.addView(actions);return box;}

    private void detailDialog(RadarItem r){MarketAnalysis a=r.analysis;StringBuilder s=new StringBuilder();s.append(a.label()).append("\n\n");for(String x:a.reasons)s.append("• ").append(x).append('\n');s.append("\nRSI Günlük / 4S: ").append(fmt(a.rsiDaily)).append(" / ").append(fmt(a.rsi4h));s.append("\nMACD hist Günlük / 4S: ").append(fmt(a.macdDaily)).append(" / ").append(fmt(a.macd4h));s.append("\nEMA20 / EMA50 / EMA200: ").append(fmt(a.ema20)).append(" / ").append(fmt(a.ema50)).append(" / ").append(fmt(a.ema200));s.append("\nATR14: ").append(fmt(a.atr));if(a.divergenceDaily.type!=Divergence.Type.NONE)s.append("\nUyumsuzluk: ").append(a.divergenceDaily.type==Divergence.Type.BULLISH?"Pozitif":"Negatif");s.append("\n\nBu ekran teknik koşulları açıklar; işlem emri değildir.");new AlertDialog.Builder(this).setTitle(a.symbol+" teknik detay").setMessage(s.toString()).setPositiveButton("Kapat",null).show();}

    private void positionDialog(){
        LinearLayout f=new LinearLayout(this);f.setOrientation(LinearLayout.VERTICAL);f.setPadding(dp(20),0,dp(20),0);Spinner symbol=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,MarketUniverse.all());symbol.setAdapter(ad);f.addView(symbol);Spinner dir=new Spinner(this);dir.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Yukarı senaryo","Aşağı senaryo"}));f.addView(dir);EditText code=input("Varant kodu (isteğe bağlı)");EditText entry=input("Dayanak giriş fiyatı");entry.setInputType(2|8192);EditText days=input("Vade bitimine kalan gün");days.setInputType(2);EditText note=input("Not");f.addView(code);f.addView(entry);f.addView(days);f.addView(note);new AlertDialog.Builder(this).setTitle("Pozisyon kaydı").setView(f).setNegativeButton("İptal",null).setPositiveButton("Kaydet",(d,w)->{String s=(String)symbol.getSelectedItem();double e=parse(entry.getText().toString());int dd=(int)parse(days.getText().toString());long now=System.currentTimeMillis(),exp=dd>0?now+dd*86400000L:0;store.addPosition(new Position(s,dir.getSelectedItemPosition()==0?"UP":"DOWN",code.getText().toString().trim(),e,now,exp,note.getText().toString().trim()));renderPositions();}).show();
    }

    private String positionHealth(Position p,MarketAnalysis a){boolean up="UP".equals(p.direction);if((up&&a.state==MarketAnalysis.State.STRONG_DOWN)||(!up&&a.state==MarketAnalysis.State.STRONG_UP))return"SENARYO ZAYIFLADI • teknik yön ters";if(!Double.isNaN(a.invalidation)&&((up&&a.price<a.invalidation)||(!up&&a.price>a.invalidation)))return"SENARYO ZAYIFLADI • bozulma seviyesi aşıldı";if((up&&a.divergenceDaily.type==Divergence.Type.BEARISH)||(!up&&a.divergenceDaily.type==Divergence.Type.BULLISH))return"ÇIKIŞ İZLE • karşı uyumsuzluk var";return"SENARYO KORUNUYOR";}
    private void requestNotification(){if(Build.VERSION.SDK_INT>=33&&checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},801);}
    private void status(String s,int c){status.setText(s);status.setTextColor(c);}private void empty(String s){LinearLayout p=panel();p.addView(tv(s,13,MUTED,false));content.addView(p);}private LinearLayout panel(){LinearLayout p=new LinearLayout(this);p.setOrientation(LinearLayout.VERTICAL);p.setPadding(dp(14),dp(13),dp(14),dp(13));p.setBackground(pill(PANEL,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.bottomMargin=dp(10);p.setLayoutParams(lp);return p;}
    private Button button(String s,int color){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setTextSize(11);b.setAllCaps(false);b.setBackground(pill(color,13));return b;}private TextView tv(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextSize(sp);v.setTextColor(color);v.setPadding(0,dp(3),0,dp(3));if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setTextColor(Color.BLACK);e.setHintTextColor(Color.DKGRAY);return e;}
    private GradientDrawable pill(int c,int r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(dp(r));return g;}private int dp(int x){return(int)(x*getResources().getDisplayMetrics().density+.5f);}private int stateColor(MarketAnalysis.State s){return switch(s){case STRONG_UP,CONFIRM_UP,WATCH_UP->GREEN;case STRONG_DOWN,CONFIRM_DOWN,WATCH_DOWN->RED;default->YELLOW;};}
    private String fmt(double x){if(Double.isNaN(x)||Double.isInfinite(x))return"—";NumberFormat n=NumberFormat.getNumberInstance(new Locale("tr","TR"));n.setMaximumFractionDigits(2);n.setMinimumFractionDigits(0);return n.format(x);}private String pct(double x){return Double.isNaN(x)?"—":(x>=0?"+":"")+String.format(Locale.US,"%.2f%%",x).replace('.',',');}private String now(){return new SimpleDateFormat("dd.MM.yyyy HH:mm",new Locale("tr","TR")).format(new Date());}private double parse(String s){try{return Double.parseDouble(s.trim().replace(',','.'));}catch(Exception e){return Double.NaN;}}private String safe(String s){return s==null?"Bilinmeyen hata":s;}
}
