package com.mizandar.varantmatik;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.mizandar.varantmatik.core.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public final class MainActivity extends Activity {
    private static final int BG=Color.rgb(7,16,28), PANEL=Color.rgb(15,27,45), PANEL2=Color.rgb(20,35,57);
    private static final int TEXT=Color.rgb(238,244,252), MUTED=Color.rgb(150,168,190), GREEN=Color.rgb(55,205,130), RED=Color.rgb(239,102,102), YELLOW=Color.rgb(239,200,79), BLUE=Color.rgb(91,157,255);
    private final ExecutorService executor=Executors.newSingleThreadExecutor();
    private final Handler ui=new Handler(Looper.getMainLooper());
    private final DecimalFormat d2=new DecimalFormat("0.00");
    private MarketScanner scanner;
    private Spinner symbolSpinner;
    private Button analyzeButton, backtestButton, warrantsButton, evaluateButton;
    private LinearLayout resultBox, backtestBox;
    private TextView status;
    private RadarItem last;

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(BG);getWindow().setNavigationBarColor(BG);
        scanner=new MarketScanner(this);
        setContentView(build());
    }

    @Override protected void onDestroy(){super.onDestroy();executor.shutdownNow();}

    private View build(){
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(BG);root.setPadding(dp(18),dp(18),dp(18),dp(28));
        root.setOnApplyWindowInsetsListener((v,in)->{v.setPadding(dp(18),in.getSystemWindowInsetTop()+dp(14),dp(18),in.getSystemWindowInsetBottom()+dp(20));return in;});

        root.addView(tv("VarantMatik Lite 1.1.1",30,GREEN,true));
        TextView sub=tv("Dayanağı seç • analiz et • geçmişte doğrula • sonra varanta geç",14,MUTED,false);sub.setPadding(0,dp(2),0,dp(18));root.addView(sub);

        LinearLayout pick=panel();
        pick.addView(tv("1  DAYANAK SEÇ",12,MUTED,true));
        pick.addView(tv("XU030 + DAX + güncel BIST30 evreni",11,MUTED,false));
        symbolSpinner=new Spinner(this);
        ArrayAdapter<String> ad=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,MarketUniverse.all()){
            @Override public View getView(int p,View c,android.view.ViewGroup parent){TextView v=(TextView)super.getView(p,c,parent);v.setTextColor(TEXT);v.setTextSize(20);v.setPadding(dp(8),dp(12),dp(8),dp(12));return v;}
            @Override public View getDropDownView(int p,View c,android.view.ViewGroup parent){TextView v=(TextView)super.getDropDownView(p,c,parent);v.setTextColor(Color.BLACK);v.setTextSize(18);return v;}
        };
        symbolSpinner.setAdapter(ad);pick.addView(symbolSpinner,new LinearLayout.LayoutParams(-1,dp(58)));
        analyzeButton=button("ANALİZ ET",GREEN);analyzeButton.setOnClickListener(v->analyze());pick.addView(analyzeButton,new LinearLayout.LayoutParams(-1,dp(52)));
        root.addView(pick);

        status=tv("Hazır",12,MUTED,false);status.setPadding(dp(4),dp(4),0,dp(8));root.addView(status);

        resultBox=panel();resultBox.addView(tv("2  ANALİZ SONUCU",12,MUTED,true));resultBox.addView(tv("Bir dayanak seçip ANALİZ ET'e bas.",14,TEXT,false));root.addView(resultBox);

        LinearLayout validation=panel();
        validation.addView(tv("3  GEÇMİŞ DOĞRULAMA",12,MUTED,true));
        validation.addView(tv("Aynı karar motoru geçmiş mumlarda ileriye bakmadan yürütülür. Yalnız yeni TEYİT/GÜÇLÜ serileri sinyal sayılır.",12,TEXT,false));
        backtestButton=button("SEÇİLİ DAYANAĞI GEÇMİŞTE TEST ET",PANEL2);backtestButton.setOnClickListener(v->backtest());validation.addView(backtestButton,new LinearLayout.LayoutParams(-1,dp(50)));
        backtestBox=new LinearLayout(this);backtestBox.setOrientation(LinearLayout.VERTICAL);backtestBox.setPadding(0,dp(8),0,0);backtestBox.addView(tv("Henüz test yapılmadı.",12,MUTED,false));validation.addView(backtestBox);
        root.addView(validation);

        LinearLayout w=panel();w.addView(tv("4  VARANTA GEÇ",12,MUTED,true));
        w.addView(tv("İZLE yeterli değildir. Varant butonu yalnız TEYİT veya GÜÇLÜ durumda açılır.",13,TEXT,false));
        warrantsButton=button("VARANTLARI GÖR",BLUE);warrantsButton.setEnabled(false);warrantsButton.setOnClickListener(v->openWarrants());w.addView(warrantsButton,new LinearLayout.LayoutParams(-1,dp(50)));
        evaluateButton=button("SEÇTİĞİM VARANTI DEĞERLENDİR",PANEL2);evaluateButton.setOnClickListener(v->warrantDialog());w.addView(evaluateButton,new LinearLayout.LayoutParams(-1,dp(50)));
        TextView delayed=tv("Varant listesi dış kaynaktan açılır; kamuya açık listede veriler yaklaşık 15 dakika gecikmeli olabilir.",11,MUTED,false);delayed.setPadding(0,dp(8),0,0);w.addView(delayed);
        root.addView(w);

        TextView note=tv("Geçmiş test dayanağın yönünü ölçer; varantın gerçek getirisini ölçmez. Makas, zaman değeri, volatilite ve kaldıraç nedeniyle varant sonucu farklı olabilir. Geçmiş performans gelecek sonucu garanti etmez.",11,YELLOW,false);note.setPadding(dp(4),dp(6),dp(4),0);root.addView(note);
        scroll.addView(root);return scroll;
    }

    private void analyze(){
        final String s=String.valueOf(symbolSpinner.getSelectedItem());
        analyzeButton.setEnabled(false);warrantsButton.setEnabled(false);last=null;
        status.setText(s+" • günlük + 4 saat verisi yükleniyor…");status.setTextColor(YELLOW);
        executor.execute(()->{
            try{
                RadarItem r=scanner.scanOne(s,true);
                ui.post(()->{last=r;analyzeButton.setEnabled(true);render(r);status.setText("Analiz tamamlandı • "+now());status.setTextColor(GREEN);});
            }catch(Exception e){
                ui.post(()->{analyzeButton.setEnabled(true);status.setText("Veri alınamadı: "+safe(e.getMessage()));status.setTextColor(RED);});
            }
        });
    }

    private void backtest(){
        final String s=String.valueOf(symbolSpinner.getSelectedItem());
        backtestButton.setEnabled(false);analyzeButton.setEnabled(false);
        backtestBox.removeAllViews();backtestBox.addView(tv("Geçmiş veri hazırlanıyor…",12,YELLOW,false));
        status.setText(s+" • geçmiş doğrulama başlıyor…");status.setTextColor(YELLOW);
        executor.execute(()->{
            try{
                BacktestReport r=scanner.backtest(s,true,text->ui.post(()->{status.setText(text);status.setTextColor(YELLOW);}));
                ui.post(()->{backtestButton.setEnabled(true);analyzeButton.setEnabled(true);renderBacktest(r);status.setText("Geçmiş doğrulama tamamlandı • "+now());status.setTextColor(GREEN);});
            }catch(Exception e){
                ui.post(()->{backtestButton.setEnabled(true);analyzeButton.setEnabled(true);backtestBox.removeAllViews();backtestBox.addView(tv("Test yapılamadı: "+safe(e.getMessage()),12,RED,false));status.setText("Geçmiş doğrulama başarısız");status.setTextColor(RED);});
            }
        });
    }

    private void render(RadarItem r){
        resultBox.removeAllViews();resultBox.addView(tv("2  ANALİZ SONUCU",12,MUTED,true));
        MarketAnalysis a=r.analysis;
        resultBox.addView(tv(a.symbol+"   "+fmt(a.price),25,TEXT,true));
        resultBox.addView(tv("Günlük "+pct(a.changePct),14,Double.isNaN(a.changePct)?MUTED:(a.changePct>=0?GREEN:RED),true));
        TextView state=tv(a.label(),17,stateColor(a.state),true);state.setPadding(dp(12),dp(10),dp(12),dp(10));state.setBackground(pill(PANEL2,14));resultBox.addView(state);
        resultBox.addView(tv("Günlük RSI: "+fmt(a.rsiDaily)+"   •   4S RSI: "+fmt(a.rsi4h),13,TEXT,false));
        resultBox.addView(tv("Destek: "+fmt(a.support)+"   •   Direnç: "+fmt(a.resistance),13,MUTED,false));
        resultBox.addView(tv("Senaryo bozulma: "+fmt(a.invalidation),12,MUTED,false));
        if(!a.reasons.isEmpty()){
            resultBox.addView(tv("Neden?",13,TEXT,true));
            int n=Math.min(5,a.reasons.size()); for(int i=0;i<n;i++) resultBox.addView(tv("• "+a.reasons.get(i),12,TEXT,false));
        }
        String action; int color;
        if(isConfirmedUp(a.state)){action="Yukarı teyit var. CALL tarafındaki varantların yapısal özellikleri incelenebilir.";color=GREEN;}
        else if(isConfirmedDown(a.state)){action="Aşağı teyit var. PUT tarafındaki varantların yapısal özellikleri incelenebilir.";color=RED;}
        else if(isUp(a.state)){action="Yukarı eğilim izleniyor ama teyit tamam değil. Henüz varanta geçme.";color=YELLOW;}
        else if(isDown(a.state)){action="Aşağı eğilim izleniyor ama teyit tamam değil. Henüz varanta geçme.";color=YELLOW;}
        else{action="Yön net değil. Dayanağı izlemeye devam et.";color=YELLOW;}
        TextView next=tv(action,13,color,true);next.setPadding(0,dp(10),0,0);resultBox.addView(next);
        warrantsButton.setEnabled(isConfirmedUp(a.state)||isConfirmedDown(a.state));
    }

    private void renderBacktest(BacktestReport r){
        backtestBox.removeAllViews();
        backtestBox.addView(tv(r.symbol+" • walk-forward sonuç",15,TEXT,true));
        backtestBox.addView(tv("Test aralığı: "+date(r.startTime)+" – "+date(r.endTime),12,MUTED,false));
        backtestBox.addView(tv("Yeni teyit serisi: "+r.signalCount+"   •   Yukarı: "+r.upSignals+"   •   Aşağı: "+r.downSignals+"   •   Güçlü: "+r.strongSignals,12,TEXT,false));
        if(r.signalCount==0){backtestBox.addView(tv("Bu veri aralığında teyit serisi oluşmadı. Eşikler hakkında sonuç çıkarmak için örnek yok.",12,YELLOW,false));return;}
        backtestBox.addView(tv("Sonraki işlem gününde yön doğruluğu",12,MUTED,true));
        for(int i=0;i<r.horizons.length;i++){
            String line=r.horizons[i]+" gün  •  "+(Double.isNaN(r.successPct(i))?"—":("%"+d2.format(r.successPct(i))))+" doğru yön  •  ort. yönsel "+pct(r.avgSignedReturn[i])+"  •  n="+r.samples[i];
            backtestBox.addView(tv(line,12,TEXT,false));
        }
        if(!Double.isNaN(r.avgFavorable20))backtestBox.addView(tv("20 günde ort. azami lehe: +"+d2.format(r.avgFavorable20)+"%   •   ort. azami ters: "+d2.format(r.avgAdverse20)+"%",12,MUTED,false));
        String quality=r.signalCount<15?"Örneklem çok küçük; sonuç yalnız gözlem niteliğinde.":r.signalCount<30?"Örneklem sınırlı; daha fazla sinyal birikmeden güçlü sonuç çıkarma.":"Örneklem kullanılabilir boyutta; yine de farklı piyasa rejimleri ayrıca incelenmeli.";
        TextView q=tv(quality,12,r.signalCount<30?YELLOW:GREEN,true);q.setPadding(0,dp(8),0,0);backtestBox.addView(q);
        backtestBox.addView(tv("Not: Sinyal günlük kapanışta oluşmuş kabul edilir; ölçüm sonraki işlem gününün açılışından başlar. Komisyon/varant makası/zaman değeri dahil değildir.",11,MUTED,false));
    }

    private void openWarrants(){
        String url="https://www.garantibbvayatirim.com.tr/varant/varant-pusulasi";
        try{startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));}
        catch(Exception e){Toast.makeText(this,"Tarayıcı açılamadı",Toast.LENGTH_SHORT).show();}
    }

    private void warrantDialog(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(dp(12),dp(4),dp(12),0);
        EditText code=input("Varant kodu (örn. ABCDE)");
        EditText days=input("Vadeye kalan gün");days.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        EditText bid=input("P.Y. alış");bid.setInputType(8194);
        EditText ask=input("P.Y. satış");ask.setInputType(8194);
        EditText delta=input("Delta (örn. 0.45)");delta.setInputType(8194);
        EditText leverage=input("Etkin kaldıraç (örn. 5.2)");leverage.setInputType(8194);
        for(EditText e:new EditText[]{code,days,bid,ask,delta,leverage})box.addView(e);
        new AlertDialog.Builder(this).setTitle("Varant teknik filtresi").setView(box).setNegativeButton("İptal",null).setPositiveButton("DEĞERLENDİR",(d,w)->{
            try{
                String c=code.getText().toString().trim().toUpperCase(Locale.ROOT);
                int day=Integer.parseInt(days.getText().toString().trim());
                double b=Double.parseDouble(bid.getText().toString().replace(',','.'));
                double a=Double.parseDouble(ask.getText().toString().replace(',','.'));
                double de=Math.abs(Double.parseDouble(delta.getText().toString().replace(',','.')));
                double lev=Double.parseDouble(leverage.getText().toString().replace(',','.'));
                if(a<=0||b<0||a<b)throw new IllegalArgumentException();
                double mid=(a+b)/2.0, spread=(a-b)/mid*100.0;
                showWarrantResult(c,day,spread,de,lev);
            }catch(Exception ex){Toast.makeText(this,"Girdileri kontrol et",Toast.LENGTH_LONG).show();}
        }).show();
    }

    private void showWarrantResult(String code,int days,double spread,double delta,double lev){
        ArrayList<String> lines=new ArrayList<>();
        lines.add("Makas: %"+d2.format(spread)+(spread<=3?" • dar":spread<=6?" • orta":" • geniş"));
        lines.add("Vade: "+days+" gün"+(days>=45?" • rahat":days>=20?" • dikkat":" • zaman değeri riski yüksek"));
        lines.add("Delta: "+d2.format(delta)+(delta>=0.35&&delta<=0.70?" • orta hassasiyet":delta<0.25?" • düşük hassasiyet":" • yüksek hassasiyet"));
        lines.add("Etkin kaldıraç: "+d2.format(lev));
        int flags=0;if(spread>6)flags++;if(days<20)flags++;if(delta<0.20)flags++;if(lev>10)flags++;
        String head=flags==0?"Belirgin yapısal uyarı yok":flags==1?"1 yapısal uyarı var":flags+" yapısal uyarı var";
        new AlertDialog.Builder(this).setTitle((code.isEmpty()?"Varant":code)+" • "+head).setMessage(String.join("\n",lines)+"\n\nBu sonuç al/sat önerisi değildir; yalnız varantın yapısal özelliklerini özetler.").setPositiveButton("Tamam",null).show();
    }

    private EditText input(String hint){EditText e=new EditText(this);e.setHint(hint);e.setSingleLine(true);e.setPadding(dp(8),dp(9),dp(8),dp(9));return e;}
    private LinearLayout panel(){LinearLayout x=new LinearLayout(this);x.setOrientation(LinearLayout.VERTICAL);x.setPadding(dp(16),dp(14),dp(16),dp(14));x.setBackground(pill(PANEL,18));LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,0,0,dp(14));x.setLayoutParams(lp);return x;}
    private TextView tv(String s,int sp,int color,boolean bold){TextView v=new TextView(this);v.setText(s);v.setTextColor(color);v.setTextSize(sp);v.setLineSpacing(0,1.08f);if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private Button button(String s,int bg){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setBackground(pill(bg,16));return b;}
    private GradientDrawable pill(int color,float r){GradientDrawable g=new GradientDrawable();g.setColor(color);g.setCornerRadius(dp((int)r));return g;}
    private int stateColor(MarketAnalysis.State s){if(isUp(s))return GREEN;if(isDown(s))return RED;return YELLOW;}
    private boolean isUp(MarketAnalysis.State s){return s==MarketAnalysis.State.WATCH_UP||s==MarketAnalysis.State.CONFIRM_UP||s==MarketAnalysis.State.STRONG_UP;}
    private boolean isDown(MarketAnalysis.State s){return s==MarketAnalysis.State.WATCH_DOWN||s==MarketAnalysis.State.CONFIRM_DOWN||s==MarketAnalysis.State.STRONG_DOWN;}
    private boolean isConfirmedUp(MarketAnalysis.State s){return s==MarketAnalysis.State.CONFIRM_UP||s==MarketAnalysis.State.STRONG_UP;}
    private boolean isConfirmedDown(MarketAnalysis.State s){return s==MarketAnalysis.State.CONFIRM_DOWN||s==MarketAnalysis.State.STRONG_DOWN;}
    private String fmt(double x){return Double.isNaN(x)?"—":d2.format(x);}
    private String pct(double x){return Double.isNaN(x)?"—":(x>=0?"+":"")+d2.format(x)+"%";}
    private String now(){return new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.forLanguageTag("tr-TR")).format(new Date());}
    private String date(long t){return new SimpleDateFormat("dd.MM.yyyy",Locale.forLanguageTag("tr-TR")).format(new Date(t));}
    private String safe(String s){if(s==null||s.isBlank())return "veri hatası";s=s.replace('\n',' ').replace('\r',' ');return s.length()>80?s.substring(0,80)+"…":s;}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
