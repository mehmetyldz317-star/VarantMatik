# APK üretmek için kalan tek altyapı adımı

VarantMatik V8 kaynakları ve GitHub Actions iş akışı hazırdır. Bu sohbetin bağlı GitHub hesabında şu anda erişilebilir repository görünmüyor.

1. GitHub üzerinde `VarantMatik` adında boş bir repository oluşturun (README ile başlatmak uygundur).
2. Repository oluşturulduktan sonra bu sohbete yalnızca `oluşturdum` yazın.
3. Kaynakların tamamı tek commit olarak repoya aktarılabilir. `main` dalına yapılan push `.github/workflows/build-apk.yml` iş akışını otomatik başlatır.
4. İş akışı JDK 17, Android SDK 36, Build Tools 36.0.0 ve Gradle 9.6.0 ile `:app:assembleDebug` çalıştırır.
5. Başarılı build sonunda `app-debug.apk` GitHub Actions artifact olarak alınır; build başarısız olursa job logları üzerinden gerçek derleme hatası düzeltilir.

Bu yaklaşım elle APK paketlemeyi tamamen bırakır.
