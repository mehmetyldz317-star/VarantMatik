# Android Studio olmadan APK üretme

Projeyi bir GitHub deposuna yükleyin. `.github/workflows/build-apk.yml` dosyası otomatik olarak resmi Android SDK ve Gradle ortamında derleme yapar.

GitHub'da:
1. Actions sekmesine girin.
2. **Build VarantMatik APK** iş akışını seçin.
3. **Run workflow** düğmesine basın.
4. İşlem tamamlandığında **VarantMatik-V8-debug-apk** artifact'ını indirin.
5. ZIP içindeki `app-debug.apk` dosyasını telefona kurun.

İş akışı önce matematik motorunun self-testlerini çalıştırır. Testler geçmezse APK üretmez.
