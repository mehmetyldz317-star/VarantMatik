# VarantMatik V8 — Master Native Android Projesi

## Amaç
VarantMatik V8, hızlı günlük al-sat üretmek için değil; XU030, DAX ve BIST30 dayanaklarını sabırla izleyip teknik koşulların gelişimini takip etmek için tasarlanmıştır.

Temel akış:

**Radar → İzleme → Teyit → Pozisyon → Nöbetçi → Çıkış İzleme**

Uygulama doğrudan “AL/SAT” emri üretmez. Durum etiketleri teknik koşulların ne kadar hizalandığını gösterir.

## V8'de ne değişti?
- Tamamen native Android. WebView/HTML/JavaScript yok.
- Ağ çağrıları UI thread dışında çalışır; açılışta beyaz ekran/donma tasarlanmaz.
- XU030 ve DAX hızlı açılış taraması.
- BIST30 tam taraması ayrı düğmeyle.
- İki aşamalı tarama: önce günlük tüm evren, sonra endeksler/izlenenler/açık pozisyonlar ve en güçlü adaylar için 4 saat teyidi.
- Wilder RSI(14), EMA20/50/200, MACD(12,26,9), ATR(14).
- Pivot tabanlı pozitif/negatif RSI uyumsuzluğu.
- Destek/direnç, kırılım ve senaryo bozulma seviyesi.
- İzleme listesi SharedPreferences ile kalıcı.
- Pozisyon kaydı: dayanak, yön senaryosu, varant kodu, giriş fiyatı, vade, not.
- Arka plan nöbetçisi: JobScheduler, 15/30/60 dk seçenekleri.
- Bildirim yalnız önemli durum değişimlerinde.
- Basit native mini grafik (Canvas).
- Yahoo Finance veri katmanı ayrı sınıfta; ileride lisanslı veri sağlayıcıyla değiştirilebilir.

## Teknik durum makinesi
- BEKLE
- YUKARI İZLE / AŞAĞI İZLE
- YUKARI TEYİT GELİŞİYOR / AŞAĞI TEYİT GELİŞİYOR
- YUKARI KOŞULLAR GÜÇLÜ / AŞAĞI KOŞULLAR GÜÇLÜ

Tek bir RSI veya MACD değeri “sinyal” sayılmaz. Günlük trend, uyumsuzluk/destek-direnci ve 4 saat momentum birlikte değerlendirilir.

## Mum kapanışı güvenliği
Göstergeler yalnız kapanmış mumlardan hesaplanır. Güncel fiyat ayrıca gösterilir.
- BIST günlük mum: İstanbul saati yaklaşık 18:15 sonrası tamamlanmış kabul edilir.
- DAX günlük mum: Berlin saati yaklaşık 17:45 sonrası tamamlanmış kabul edilir.
- Saatlik mum: başlangıcından en az 65 dakika sonra tamamlanmış kabul edilir.
- 4 saat mumları, tamamlanmış 60 dakikalık mumların gün içinde dörderli gruplanmasıyla oluşturulur; eksik son grup kullanılmaz.

## Arka plan taraması
Android JobScheduler periyodik işi tam dakikasında çalıştırmayı garanti etmez. Minimum periyodik aralık 15 dakikadır.

Her nöbet turunda:
1. XU030 + DAX
2. İzleme listesi
3. Açık pozisyon dayanakları
4. BIST30'dan döner 8'li grup

taranır. Böylece önemli dayanaklar sık, tüm BIST30 ise daha ekonomik şekilde taranır.

## BIST30 evreni
01.07.2026–30.09.2026 dönemi için Borsa İstanbul'un 19.06.2026 dönemsel kararında BIST30'a giriş/çıkış yapılmadığından, 2026 ikinci çeyrek listesi Q3 için de geçerlidir. Projedeki 30 bileşen bu listeye göre tanımlıdır.

## Derleme
Güncel proje ayarları:
- Android Gradle Plugin: 9.4.0
- compileSdk: 36
- targetSdk: 35
- minSdk: 26
- Java: 17

Gerçek Android SDK/Gradle ortamında:

```bash
gradle assembleDebug
```

veya Android Studio ile projeyi açıp **Build > Build APK(s)**.

> Bu çalışma ortamında Android SDK bulunmadığı için APK'nın burada resmi Android build-tools ile derlenmesi mümkün olmadı. Önceki elle paketlenmiş APK yöntemi bilerek terk edilmiştir.

## Çekirdek testleri
`tools/CoreSelfTest.java` Android'den bağımsız matematik motorunu test eder:
- Wilder RSI referans örneği
- MACD hesap akışı
- ATR
- Sentetik pozitif uyumsuzluk
- Sentetik negatif uyumsuzluk
- Varant spread / içsel değer / gearing / etkin kaldıraç matematiği

Bu ortamda test sonucu: `ALL_CORE_TESTS_OK`.

## Varant matematiği
`WarrantMath` manuel varant girdileri için şunları hesaplar:
- orta fiyat
- spread yüzdesi
- içsel değer
- zaman değeri
- gearing
- etkin kaldıraç
- karda/zararda/başabaş durumu

Varant seçimi dayanak teknik senaryosundan **sonra** gelir.

## Veri notu
Yahoo Finance bu prototipte gecikmeli/ücretsiz mum kaynağıdır ve resmi Borsa İstanbul veri servisi değildir. Üretim seviyesinde uygulama için `YahooFinanceProvider` yerine lisanslı/kurumsal veri kaynağı bağlanması tavsiye edilir. Analiz motoru veri sağlayıcıdan bağımsız tutulmuştur.
