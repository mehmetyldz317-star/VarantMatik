# VarantMatik Research 1.2

Bu sürüm VarantMatik'in araştırma/doğrulama katmanıdır.

## Yeni
- 2024 Q4'ten itibaren point-in-time BIST30 üyeliği: bugünkü hisseleri geçmişe taşıyan survivorship bias azaltılır.
- Araştırma evreni 36 sembollük tarihsel birleşimdir; her sinyal yalnız hissenin o tarihte BIST30 üyesi olduğu günlerde sayılır.
- Yukarı ve aşağı teyitler ayrı raporlanır.
- XU030'a göre boğa / ayı / yatay piyasa rejimleri ayrı raporlanır.
- İlk %70 geliştirme, son %30 dokunulmamış holdout olarak ayrılır.
- 1/3/5/10/20 işlem günü için başarı, ortalama ve medyan yönsel hareket ölçülür.
- Aynı sinyal günlerinde basit EMA50 trend referansı ile kıyaslama yapılır.
- 20 gün için ortalama maksimum lehe ve ters hareket ölçülür.
- Toplu araştırma raporu panoya kopyalanabilir.
- Yahoo geçici rate-limit/server hataları için retry/backoff eklendi.

## Araştırma ilkesi
Holdout sonuçları parametre ayarlamak için kullanılmamalıdır. Bir sonraki strateji değişikliği yalnız geliştirme dönemine göre tasarlanmalı; sonra yeni, dokunulmamış bir test dönemi oluşturulmalıdır.
