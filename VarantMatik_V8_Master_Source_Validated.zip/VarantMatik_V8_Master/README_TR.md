# VarantMatik Lite 1.0

Amaç: dayanak seç -> analiz et -> yön netleşirse varant listesine geç.

İlk dayanaklar: XU030, DAX, THYAO, ASELS, BIMAS.

Analiz motoru: günlük + 4 saat; RSI14, MACD 12/26/9, EMA20/50/200, ATR14, destek/direnç, uyumsuzluk ve teyit durumu.

Varant tarafı ilk sürümde kamuya açık Garanti BBVA Yatırım Varant Pusulası'nı tarayıcıda açar. Kullanıcı seçtiği varantın vade, alış-satış, delta ve etkin kaldıraç değerlerini Lite içindeki teknik filtreye girerek yapısal özet alır.

Bu sürümde radar, arka plan nöbetçisi, otomatik 32 hisse taraması ve pozisyon modülü yoktur.
