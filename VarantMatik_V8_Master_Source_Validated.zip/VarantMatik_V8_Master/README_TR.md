# VarantMatik Lite 1.1

Amaç: önce dayanağı doğrulamak, sonra varanta geçmek.

## Evren
- XU030
- DAX
- 01.07.2026-30.09.2026 dönemi BIST30 bileşenleri (30 pay)

## Canlı analiz
- Günlük ana trend: EMA20 / EMA50 / EMA200
- RSI(14), MACD(12,26,9), ATR(14)
- Destek / direnç pivotları
- Günlük RSI uyumsuzluğu
- 60 dakikalık mumlardan oluşturulan 4 saatlik momentum teyidi
- Durumlar: BEKLE / İZLE / TEYİT / GÜÇLÜ
- Varantlara geçiş yalnız TEYİT veya GÜÇLÜ durumda açılır.

## Geçmiş doğrulama
- Günlük geçmiş: 5 yıl istenir.
- 60 dakikalık geçmiş: 2 yıl istenir; veri sağlayıcı kısıtında 1 yıl / 6 ay geri dönüşü vardır.
- Aynı karar motoru walk-forward çalıştırılır; gelecekteki mumlar sinyal hesabına girmez.
- Aynı yöndeki devam eden teyit her gün yeni sinyal sayılmaz.
- Sinyal günlük kapanışta oluşur; performans ölçümü sonraki işlem gününün açılışından başlar.
- 1 / 3 / 5 / 10 / 20 işlem günü yön doğruluğu, ortalama yönsel hareket ve 20 günlük lehe/ters hareket raporlanır.

Geçmiş performans gelecek sonucu garanti etmez. Backtest dayanağı ölçer; varant makası, zaman değeri, volatilite ve kaldıraç etkisini içermez.
